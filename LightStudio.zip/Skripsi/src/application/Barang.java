package application;

public class Barang {
    // class variable
		private String ID_BARANG,NAMA_BARANG,JENIS_BARANG,JUMLAH_BARANG,HARGA_JUAL;
	//
	
	public Barang (String id_barang, String nama_barang, String jenis_barang, String jumlah_barang, String harga_jual) {
		this.ID_BARANG = id_barang;
		this.NAMA_BARANG = nama_barang;
		this.JENIS_BARANG = jenis_barang;
		this.JUMLAH_BARANG = jumlah_barang;
		this.HARGA_JUAL = harga_jual;
	}
	public String getId_Barang() {
		return ID_BARANG;
	}
	public String getNama_Barang() {
		return NAMA_BARANG;
	}
	public String getJenis_Barang() {
		return JENIS_BARANG;
	}
	public String getJumlah_Barang() {
		return JUMLAH_BARANG;
	}
	public String getHarga_Jual() {
		return HARGA_JUAL;
	}
}
