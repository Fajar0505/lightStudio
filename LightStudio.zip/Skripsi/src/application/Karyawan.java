package application;

public class Karyawan {
    // class variable
		private String NIK,NAMA_LENGKAP,TEMPAT_TGLLAHIR,ALAMAT,KONTAK,STATUS,JENIS_KELAMIN,JABATAN;
	//
	
	public Karyawan (String nik, String nama_lengkap, String tempat_tgllahir, String alamat, String kontak, String status, String jenis_kelamin, String jabatan) {
		this.NIK = nik;
		this.NAMA_LENGKAP = nama_lengkap;
		this.TEMPAT_TGLLAHIR = tempat_tgllahir;
		this.ALAMAT = alamat;
		this.KONTAK = kontak;
		this.STATUS = status;
		this.JENIS_KELAMIN = jenis_kelamin;
		this.JABATAN = jabatan;
	}

	public String getNik() {
		return NIK;
	}
	public String getNama() {
		return NAMA_LENGKAP;
	}
	public String getTempat_Tg_lahir() {
		return TEMPAT_TGLLAHIR;
	}
	public String getAlamat() {
		return ALAMAT;
	}
	public String getKontak() {
		return KONTAK;
	}
	public String getStatus() {
		return STATUS;
	}
	public String getJenis_Kelamin() {
		return JENIS_KELAMIN;
	}
	public String getJabatan() {
		return JABATAN;
	}
}
