package application;

//import my own class
import static application.Koneksi.*;
import static application.Main.*;
import static application.Forgot_Controller.id;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;

public class Reset_Controller {
	Main Main_class = new Main(); // Object Of Main Class
	
	// FXML Codes Area
	@FXML
	private PasswordField new_password,confrim_new_password;  // Declare Fxml Component by Id
	@FXML
	private Button btn_reset,btn_back;	// Declare Fxml Component by Id
	
	public void Button_Action (ActionEvent event) {	// method for button of LOGIN_UI.FXML
		if (event.getSource() == btn_reset) {
			reset_password(); // run the method
		}else if (event.getSource() == btn_back) {
			window.setScene(layer_in_stage);	// Move to Forgot Page
		}
	}
	
	void reset_password() { // method to reset password
		// local variable
		String pass1 = new_password.getText();
		String pass2 = confrim_new_password.getText();
		int pass1lenght = pass1.length(); // count character of variable pass1
		int pass2lenght = pass2.length(); // count character of variable pass2
		
		try {
            // RETURN VALUE OBJECT DRIVER 
            Class.forName(DRIVER);

            // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
            // c is a object from Conecctor class
            //dm is object from Conecctor class that run the function(getConnection) and set the parameters
            c = dm.getConnection(DB_URL, USER, PASS);

            // buat objek statement
            // s is a object from Conecctor class
            //dm is object from Conecctor class that run the function(createStatement) 
            s = c.createStatement();
            // update password
            if (pass1.equals(pass2)) {
                r = s.executeQuery("SELECT * FROM admin WHERE id_admin='"+id+"'");
                if (r.next()){
                    if (pass1lenght < 1) {
                    	text ="NEW PASSWORD OR REPASSWORD WAS EMPTY";
                    	Main_class.login(); 		// Run Main Class Method 
                    	new_password.setText(""); 	// Set value of FXML Component By Id 
                    	confrim_new_password.setText("");	// Set value of FXML Component By Id
                    } else if (pass2lenght < 1) {
                    	text ="NEW PASSWORD OR REPASSWORD WAS EMPTY";
                    	Main_class.login();			// Run Main Class Method 
                        new_password.setText(""); 	// Set value of FXML Component By Id 
                        confrim_new_password.setText(""); 	// Set value of FXML Component By Id
                    }else {
                        s.executeUpdate("UPDATE admin SET password ='"+pass1+"' WHERE id_admin='"+id+"'");
                        text="PASSWORD HAS CHANGED";
                        Main_class.login(); 		// Run Main Class Method 
                        new_password.setText(""); 	// Set value of FXML Component By Id
                        confrim_new_password.setText(""); // Set value of FXML Component By Id
                        window.setScene(layer_in_stage); 	// move to scene(login_ui)
                    }
                }
            }else{
            	text="NEW PASSWORD AND REPASSWORD DIDN'T MATCH";
                Main_class.login();// run method
                new_password.setText(""); 	// Set value of FXML Component By Id
                confrim_new_password.setText(""); // Set value of FXML Component By Id
            }						
			
		} catch (Exception e) {
			e.printStackTrace();// show error
		}
		
	}
}
