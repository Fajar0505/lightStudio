package application;

//IMPORT ATTRIBUTES FROM MY OWN CLASS
import static application.Koneksi.*;
import static application.Main.*;
import static application.Login_Controller.*;

import java.net.URL;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;
import java.util.ResourceBundle;

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.VerticalAlignment;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class Pendapatan_Controller {
	// location to save pdf file
	static final String location = "C:\\Users\\Fajar\\Documents\\Light Studio\\Report\\pendapatan.pdf";
	// Create Object for Main Class
	Main Main_class = new Main(); 
	// Class Variable
	static String Kode;
	static String status_options="";
	static String kelamin_options="";
	int get_gaji;
	
	//  FXML CODES AREA
	@FXML
	private Label username,status;
	@FXML
	private Button pembelian_btn,barang_btn,penjualan_btn,gaji_karyawan_btn,pendapatan_btn,update_btn,show_btn,
	suplier_btn,karyawan_btn,admin_btn,keluar_btn,search_btn,pdf_button;
	@FXML
	private TableView<Pendapatan> table;
	@FXML
	private TableColumn<Pendapatan, String> tanggal_col,modal_col,omset_col,p_gaji_col,profit_col;
	@FXML
	private TextField search_field;
	
	//Methos For Buttons of FXML File
	public void Button_Action(ActionEvent event) {
		if (event.getSource() == penjualan_btn) {
			Direktur_Controller Direktur_Controller_Object = fxml_file2.getController(); // Object Controller Class		
			// Run Method From Other Controllers
			Direktur_Controller_Object.show_name();
			Direktur_Controller_Object.show_data();			
			window.setScene(layer_in_stage2); //Move to Penjualan Page
		}else if (event.getSource() == barang_btn) {
			Barang_Controller Barang_Controller_Object = fxml_file10.getController();	
			Barang_Controller_Object.show_name();// Run Method From Other Controllers
			Barang_Controller_Object.show_data();
			window.setScene(layer_in_stage10); //Move to Barang Page
		}else if (event.getSource() == pembelian_btn) {
			Pembelian_Controller Pembelian_Controller_Object = fxml_file9.getController();	
			Pembelian_Controller_Object.show_name();// Run Method From Other Controllers
			Pembelian_Controller_Object.show_data();
			window.setScene(layer_in_stage9); //Move to Pembelian Page
		}else if (event.getSource() == gaji_karyawan_btn) {
			Gaji_Controller Gaji_Controller_Object = fxml_file8.getController();	
			Gaji_Controller_Object.show_name();// Run Method From Other Controllers
			Gaji_Controller_Object.show_data();
			window.setScene(layer_in_stage8); //Move to Gaji Page
		}else if (event.getSource() == pendapatan_btn) {
			Pendapatan_Controller Pendapatan_Controller_Object = fxml_file12.getController();
			Pendapatan_Controller_Object.MODAL(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.PENGELUARAN_GAJI(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.OMSET(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.MOENY(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.show_data(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.show_name(); // RUN METHOD FROM OTHER CONTROLLER
			window.setScene(layer_in_stage12); //Move to Pendapatan Page
		}else if (event.getSource() == suplier_btn) {
			// Object Controller Class
			Suplier_Controller Suplier_Controller_Object = fxml_file5.getController();	
			Suplier_Controller_Object.show_name();// Run Method From Other Controllers
			Suplier_Controller_Object.show_data();	
			window.setScene(layer_in_stage5); //Move to Suplier Page
		}else if (event.getSource() == karyawan_btn) {
			// Object Controller Class
			Karyawan_Controller Karyawan_Controller_Object = fxml_file6.getController();	
			Karyawan_Controller_Object.show_name();// Run Method From Other Controllers
			Karyawan_Controller_Object.show_data();// Run Method From Other Controllers
			window.setScene(layer_in_stage6); //Move to Karyawan Page			
		}else if (event.getSource() == admin_btn) {
			// Object Controller Class
			Admin_Controller Admin_Controller_Object = fxml_file7.getController();	
			Admin_Controller_Object.show_name();// Run Method From Other Controllers
			Admin_Controller_Object.show_data();// Run Method From Other Controllers
			window.setScene(layer_in_stage7); //Move to Admin Page
		}else if (event.getSource() == keluar_btn) {
			window.setX(350);
			window.setY(170);
			window.setScene(layer_in_stage);
			login_username =""; 
		}
		else if (event.getSource() == search_btn) {
			search_data();
		}
		else if (event.getSource() == pdf_button) {
			Create_pdf(); 
		}
	}
				
	//method to show admin's name
	public void show_name() { 
		username.setText(login_username);
		status.setText(index);
	}
	
	//  Method To Visible FXML Components
	public void BUTTONS_VISIBLE() {
        if (index.equals("KARYAWAN")) {
        	// set visible for menu buttons
        	gaji_karyawan_btn.setVisible(false);
        	pendapatan_btn.setVisible(false);
        	suplier_btn.setVisible(false);
        	karyawan_btn.setVisible(false);
        	admin_btn.setVisible(false);	        	
		}
	}
	
	public void MODAL() {
		try {
	        // RETURN VALUE OBJECT DRIVER 
	        Class.forName(DRIVER);
	
	        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	        // c is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	        c = dm.getConnection(DB_URL, USER, PASS);
	
	        // buat objek statement
	        // s is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(createStatement) 
	        s = c.createStatement();
	        
	        // RETURN VALUE OBJECT DRIVER 
	        Class.forName(DRIVER2);
	
	        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	        // c is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	        c2 = dm2.getConnection(DB_URL, USER, PASS);
	
	        // buat objek statement
	        // s is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(createStatement) 
	        s2 = c2.createStatement();
	        
	        // DELETE MODAL_TEB ALL VALUES
	        s2.execute("DELETE FROM modal_teb");
			
	        // difine Resultset as statment to exucute query to admin table
	        // r is Resultset object
	        r = s.executeQuery("SELECT * FROM pembelian");
	        
	        // FILL MODAL VALUE
	        while (r.next()) {
	        	String get_tgl_pembelian =r.getString("tgl_pembelian"); 		// get date value from pembelian table	        	
	        	int get_harga_total = Integer.valueOf(r.getInt("harga_total"));	// parse harga_beli(pembelian_table) to int
	        	
	        	LocalDate get_tgl_pembelian_to_localdate = LocalDate.parse(get_tgl_pembelian); 	// PARSE STRING TO LOCALDATE
	    		int month = get_tgl_pembelian_to_localdate.getMonthValue(); 					// value of months 1-12       	
	    		
	    		DateTimeFormatter months_years = DateTimeFormatter.ofPattern("MM-YYYY"); // GENERATOR MM-YYYY FOR LOCALDATE
	    		DateTimeFormatter year_month_day = DateTimeFormatter.ofPattern("yyyy-MM-dd"); // GENERATOR MM-YYYY FOR LOCALDATE
	    		String months_years_string = get_tgl_pembelian_to_localdate.format(months_years); // CONVER MONTHS_YEARS TO STRING
	    		String year_month_day_string = get_tgl_pembelian_to_localdate.format(year_month_day);
	            
	            
	    		if (month == 1) {
					r2 = s2.executeQuery("SELECT * FROM modal_teb WHERE date='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO modal_teb VALUES('"+months_years_string+"','"+year_month_day_string+"','"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
						int get_modal =Integer.valueOf(r2.getString("modal")); // parse modal(modal_teb table) to int
						int modal_final = get_modal + get_harga_total;
						String insert_2 = "UPDATE modal_teb SET modal='"+modal_final+"' WHERE date='"+months_years_string+"'";
						s2.execute(insert_2);
					}
					
				}else if (month == 2) {
					r2 = s2.executeQuery("SELECT * FROM modal_teb WHERE date='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO modal_teb VALUES('"+months_years_string+"','"+year_month_day_string+"','"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
						int get_modal =Integer.valueOf(r2.getString("modal")); // parse modal(modal_teb table) to int
						int modal_final = get_modal + get_harga_total;
						String insert_2 = "UPDATE modal_teb SET modal='"+modal_final+"' WHERE date='"+months_years_string+"'";
						s2.execute(insert_2);
					}
					
				}else if (month == 3) {
					r2 = s2.executeQuery("SELECT * FROM modal_teb WHERE date='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO modal_teb VALUES('"+months_years_string+"','"+year_month_day_string+"','"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
						int get_modal =Integer.valueOf(r2.getString("modal")); // parse modal(modal_teb table) to int
						int modal_final = get_modal + get_harga_total;
						String insert_2 = "UPDATE modal_teb SET modal='"+modal_final+"' WHERE date='"+months_years_string+"'";
						s2.execute(insert_2);
					}
					
				}else if (month == 4) {
					r2 = s2.executeQuery("SELECT * FROM modal_teb WHERE date='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO modal_teb VALUES('"+months_years_string+"','"+year_month_day_string+"','"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
						int get_modal =Integer.valueOf(r2.getString("modal")); // parse modal(modal_teb table) to int
						int modal_final = get_modal + get_harga_total;
						String insert_2 = "UPDATE modal_teb SET modal='"+modal_final+"' WHERE date='"+months_years_string+"'";
						s2.execute(insert_2);
					}
					
				}else if (month == 5) {
					r2 = s2.executeQuery("SELECT * FROM modal_teb WHERE date='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO modal_teb VALUES('"+months_years_string+"','"+year_month_day_string+"','"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
						int get_modal =Integer.valueOf(r2.getString("modal")); // parse modal(modal_teb table) to int
						int modal_final = get_modal + get_harga_total;
						String insert_2 = "UPDATE modal_teb SET modal='"+modal_final+"' WHERE date='"+months_years_string+"'";
						s2.execute(insert_2);
					}
					
				}else if (month == 6) {
					r2 = s2.executeQuery("SELECT * FROM modal_teb WHERE date='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO modal_teb VALUES('"+months_years_string+"','"+year_month_day_string+"','"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
						int get_modal =Integer.valueOf(r2.getString("modal")); // parse modal(modal_teb table) to int
						int modal_final = get_modal + get_harga_total;
						String insert_2 = "UPDATE modal_teb SET modal='"+modal_final+"' WHERE date='"+months_years_string+"'";
						s2.execute(insert_2);
					}
					
				}else if (month == 7) {
					r2 = s2.executeQuery("SELECT * FROM modal_teb WHERE date='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO modal_teb VALUES('"+months_years_string+"','"+year_month_day_string+"','"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
						int get_modal =Integer.valueOf(r2.getString("modal")); // parse modal(modal_teb table) to int
						int modal_final = get_modal + get_harga_total;
						String insert_2 = "UPDATE modal_teb SET modal='"+modal_final+"' WHERE date='"+months_years_string+"'";
						s2.execute(insert_2);
					}
										
				}else if (month == 8) {
					r2 = s2.executeQuery("SELECT * FROM modal_teb WHERE date='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO modal_teb VALUES('"+months_years_string+"','"+year_month_day_string+"','"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
						int get_modal =Integer.valueOf(r2.getString("modal")); // parse modal(modal_teb table) to int
						int modal_final = get_modal + get_harga_total;
						String insert_2 = "UPDATE modal_teb SET modal='"+modal_final+"' WHERE date='"+months_years_string+"'";
						s2.execute(insert_2);
					}
									
				}else if (month == 9) {
					r2 = s2.executeQuery("SELECT * FROM modal_teb WHERE date='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO modal_teb VALUES('"+months_years_string+"','"+year_month_day_string+"','"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
						int get_modal =Integer.valueOf(r2.getString("modal")); // parse modal(modal_teb table) to int
						int modal_final = get_modal + get_harga_total;
						String insert_2 = "UPDATE modal_teb SET modal='"+modal_final+"' WHERE date='"+months_years_string+"'";
						s2.execute(insert_2);
					}
					
				}else if (month == 10) {
					r2 = s2.executeQuery("SELECT * FROM modal_teb WHERE date='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO modal_teb VALUES('"+months_years_string+"','"+year_month_day_string+"','"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
						int get_modal =Integer.valueOf(r2.getString("modal")); // parse modal(modal_teb table) to int
						int modal_final = get_modal + get_harga_total;
						String insert_2 = "UPDATE modal_teb SET modal='"+modal_final+"' WHERE date='"+months_years_string+"'";
						s2.execute(insert_2);
					}
					
				}else if (month == 11) {
					r2 = s2.executeQuery("SELECT * FROM modal_teb WHERE date='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO modal_teb VALUES('"+months_years_string+"','"+year_month_day_string+"','"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
						int get_modal =Integer.valueOf(r2.getString("modal")); // parse modal(modal_teb table) to int
						int modal_final = get_modal + get_harga_total;
						String insert_2 = "UPDATE modal_teb SET modal='"+modal_final+"' WHERE date='"+months_years_string+"'";
						s2.execute(insert_2);
					}
					
				}else if (month == 12) {
					r2 = s2.executeQuery("SELECT * FROM modal_teb WHERE date='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO modal_teb VALUES('"+months_years_string+"','"+year_month_day_string+"','"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
						int get_modal =Integer.valueOf(r2.getString("modal")); // parse modal(modal_teb table) to int
						int modal_final = get_modal + get_harga_total;
						String insert_2 = "UPDATE modal_teb SET modal='"+modal_final+"' WHERE date='"+months_years_string+"'";
						s2.execute(insert_2);
					}			
				}    		
			}// WHILE
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void OMSET() {
		try {
	        // RETURN VALUE OBJECT DRIVER 
	        Class.forName(DRIVER);
	
	        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	        // c is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	        c = dm.getConnection(DB_URL, USER, PASS);
	
	        // buat objek statement
	        // s is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(createStatement) 
	        s = c.createStatement();
	        
	        // RETURN VALUE OBJECT DRIVER 
	        Class.forName(DRIVER2);
	
	        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	        // c is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	        c2 = dm2.getConnection(DB_URL, USER, PASS);
	
	        // buat objek statement
	        // s is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(createStatement) 
	        s2 = c2.createStatement();
	        
	        // DELETE MODAL_TEB ALL VALUES
	        s2.execute("DELETE FROM omset");
			
	        // difine Resultset as statment to exucute query to admin table
	        // r is Resultset object
	        r = s.executeQuery("SELECT * FROM penjualan");
	        
	        // FILL MODAL VALUE
	        while (r.next()) {
	        	String get_tgl_transaksi =r.getString("tanggal_transaksi"); 		// get date value from penjualan table	        	
	        	int get_harga_total = Integer.valueOf(r.getString("harga_total"));		// parse harga_beli(penjualan) to int
	        	LocalDate get_tgl_penjualan_to_localdate = LocalDate.parse(get_tgl_transaksi); 	// PARSE STRING TO LOCALDATE
	    		int month = get_tgl_penjualan_to_localdate.getMonthValue(); 					// value of months 1-12       	
	    		
	    		DateTimeFormatter months_years = DateTimeFormatter.ofPattern("MM-YYYY"); // GENERATOR MM-YYYY FOR LOCALDATE
	    		//DateTimeFormatter year_month_day = DateTimeFormatter.ofPattern("yyyy-MM-dd"); // GENERATOR MM-YYYY FOR LOCALDATE
	    		String months_years_string = get_tgl_penjualan_to_localdate.format(months_years); // CONVER MONTHS_YEARS TO STRING
	    		//String year_month_day_string = get_tgl_penjualan_to_localdate.format(year_month_day);
	            	            
	    		if (month == 1) {
					r2 = s2.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO omset VALUES('"+months_years_string+"',"+"'"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_omset = r2.getInt("omsett"); // parse modal(modal_teb table) to int
						int omset_final = get_omset + get_harga_total;
						String insert_2 = "UPDATE omset SET omsett='"+omset_final+"' WHERE date_omset='"+months_years_string+"'";
						s2.execute(insert_2);
					}	
					
				}else if (month == 2) {
					r2 = s2.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO omset VALUES('"+months_years_string+"',"+"'"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_omset = r2.getInt("omsett"); // parse modal(modal_teb table) to int
						int omset_final = get_omset + get_harga_total;
						String insert_2 = "UPDATE omset SET omsett='"+omset_final+"' WHERE date_omset='"+months_years_string+"'";
						s2.execute(insert_2);
					}	
					
				}else if (month == 3) {
					r2 = s2.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO omset VALUES('"+months_years_string+"',"+"'"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_omset = r2.getInt("omsett"); // parse modal(modal_teb table) to int
						int omset_final = get_omset + get_harga_total;
						String insert_2 = "UPDATE omset SET omsett='"+omset_final+"' WHERE date_omset='"+months_years_string+"'";
						s2.execute(insert_2);
					}	
					
				}else if (month == 4) {
					r2 = s2.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO omset VALUES('"+months_years_string+"',"+"'"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_omset = r2.getInt("omsett"); // parse modal(modal_teb table) to int
						int omset_final = get_omset + get_harga_total;
						String insert_2 = "UPDATE omset SET omsett='"+omset_final+"' WHERE date_omset='"+months_years_string+"'";
						s2.execute(insert_2);
					}		
					
				}else if (month == 5) {
					r2 = s2.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO omset VALUES('"+months_years_string+"',"+"'"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_omset = r2.getInt("omsett"); // parse modal(modal_teb table) to int
						int omset_final = get_omset + get_harga_total;
						String insert_2 = "UPDATE omset SET omsett='"+omset_final+"' WHERE date_omset='"+months_years_string+"'";
						s2.execute(insert_2);
					}	
					
				}else if (month == 6) {
					r2 = s2.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO omset VALUES('"+months_years_string+"',"+"'"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_omset = r2.getInt("omsett"); // parse modal(modal_teb table) to int
						int omset_final = get_omset + get_harga_total;
						String insert_2 = "UPDATE omset SET omsett='"+omset_final+"' WHERE date_omset='"+months_years_string+"'";
						s2.execute(insert_2);
					}	
					
				}else if (month == 7) {
					r2 = s2.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO omset VALUES('"+months_years_string+"',"+"'"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_omset = r2.getInt("omsett"); // parse modal(modal_teb table) to int
						int omset_final = get_omset + get_harga_total;
						String insert_2 = "UPDATE omset SET omsett='"+omset_final+"' WHERE date_omset='"+months_years_string+"'";
						s2.execute(insert_2);
					}	
										
				}else if (month == 8) {
					r2 = s2.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO omset VALUES('"+months_years_string+"',"+"'"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_omset = r2.getInt("omsett"); // parse modal(modal_teb table) to int
						int omset_final = get_omset + get_harga_total;
						String insert_2 = "UPDATE omset SET omsett='"+omset_final+"' WHERE date_omset='"+months_years_string+"'";
						s2.execute(insert_2);
					}	
									
				}else if (month == 9) {
					r2 = s2.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO omset VALUES('"+months_years_string+"',"+"'"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_omset = r2.getInt("omsett"); // parse modal(modal_teb table) to int
						int omset_final = get_omset + get_harga_total;
						String insert_2 = "UPDATE omset SET omsett='"+omset_final+"' WHERE date_omset='"+months_years_string+"'";
						s2.execute(insert_2);
					}	
					
				}else if (month == 10) {
					r2 = s2.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO omset VALUES('"+months_years_string+"',"+"'"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_omset = r2.getInt("omsett"); // parse modal(modal_teb table) to int
						int omset_final = get_omset + get_harga_total;
						String insert_2 = "UPDATE omset SET omsett='"+omset_final+"' WHERE date_omset='"+months_years_string+"'";
						s2.execute(insert_2);
					}	
					
				}else if (month == 11) {
					r2 = s2.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO omset VALUES('"+months_years_string+"',"+"'"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_omset = r2.getInt("omsett"); // parse modal(modal_teb table) to int
						int omset_final = get_omset + get_harga_total;
						String insert_2 = "UPDATE omset SET omsett='"+omset_final+"' WHERE date_omset='"+months_years_string+"'";
						s2.execute(insert_2);
					}	
					
				}else if (month == 12) {
					r2 = s2.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO omset VALUES('"+months_years_string+"',"+"'"+get_harga_total+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_omset = r2.getInt("omsett"); // parse modal(modal_teb table) to int
						int omset_final = get_omset + get_harga_total;
						String insert_2 = "UPDATE omset SET omsett='"+omset_final+"' WHERE date_omset='"+months_years_string+"'";
						s2.execute(insert_2);
					}				
				}    		
			}// WHILE
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void PENGELUARAN_GAJI() {
		try {
	        // RETURN VALUE OBJECT DRIVER 
	        Class.forName(DRIVER);
	
	        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	        // c is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	        c = dm.getConnection(DB_URL, USER, PASS);
	
	        // buat objek statement
	        // s is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(createStatement) 
	        s = c.createStatement();
	        
	        // RETURN VALUE OBJECT DRIVER 
	        Class.forName(DRIVER2);
	
	        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	        // c is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	        c2 = dm2.getConnection(DB_URL, USER, PASS);
	
	        // buat objek statement
	        // s is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(createStatement) 
	        s2 = c2.createStatement();
	        
	        // DELETE MODAL_TEB ALL VALUES
	        s2.execute("DELETE FROM pengeluaran_gaji");
			
	        // difine Resultset as statment to exucute query to admin table
	        // r is Resultset object
	        r = s.executeQuery("SELECT * FROM gaji_karyawan");
	        
	        // FILL MODAL VALUE
	        while (r.next()) {
	        	String get_tgl_pemberian =r.getString("TANGGAL_PEMBERIAN"); 		// get date value from gaji_karyawan table	        	
	        	int get_total_gaji = Integer.valueOf(r.getString("TOTAL_GAJI"));		// parse harga_beli(gaji_karyawan) to int
	        	LocalDate get_tgl_pemberian_to_localdate = LocalDate.parse(get_tgl_pemberian); 	// PARSE STRING TO LOCALDATE
	    		int month = get_tgl_pemberian_to_localdate.getMonthValue(); 					// value of months 1-12       	
	    		
	    		DateTimeFormatter months_years = DateTimeFormatter.ofPattern("MM-YYYY"); // GENERATOR MM-YYYY FOR LOCALDATE
	    		String months_years_string = get_tgl_pemberian_to_localdate.format(months_years); // CONVER MONTHS_YEARS TO STRING
	            	            
	    		if (month == 1) {
					r2 = s2.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO pengeluaran_gaji VALUES('"+months_years_string+"',"+"'"+get_total_gaji+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_total_gaji2 = r2.getInt("total_gaji"); // parse modal(modal_teb table) to int
						int pengeluran_gaji_final = get_total_gaji2 + get_total_gaji;
						String insert_2 = "UPDATE pengeluaran_gaji SET total_gaji='"+pengeluran_gaji_final+"' WHERE tanggal_gaji='"+months_years_string+"'";
						s2.execute(insert_2);
					}	
					
				}
    			else if (month == 2) {
    				r2 = s2.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO pengeluaran_gaji VALUES('"+months_years_string+"',"+"'"+get_total_gaji+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_total_gaji2 = r2.getInt("total_gaji"); // parse modal(modal_teb table) to int
						int pengeluran_gaji_final = get_total_gaji2 + get_total_gaji;
						String insert_2 = "UPDATE pengeluaran_gaji SET total_gaji='"+pengeluran_gaji_final+"' WHERE tanggal_gaji='"+months_years_string+"'";
						s2.execute(insert_2);
				}	
					
				}else if (month == 3) {
					r2 = s2.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO pengeluaran_gaji VALUES('"+months_years_string+"',"+"'"+get_total_gaji+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_total_gaji2 = r2.getInt("total_gaji"); // parse modal(modal_teb table) to int
						int pengeluran_gaji_final = get_total_gaji2 + get_total_gaji;
						String insert_2 = "UPDATE pengeluaran_gaji SET total_gaji='"+pengeluran_gaji_final+"' WHERE tanggal_gaji='"+months_years_string+"'";
						s2.execute(insert_2);
				}	
					
				}else if (month == 4) {
					r2 = s2.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO pengeluaran_gaji VALUES('"+months_years_string+"',"+"'"+get_total_gaji+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_total_gaji2 = r2.getInt("total_gaji"); // parse modal(modal_teb table) to int
						int pengeluran_gaji_final = get_total_gaji2 + get_total_gaji;
						String insert_2 = "UPDATE pengeluaran_gaji SET total_gaji='"+pengeluran_gaji_final+"' WHERE tanggal_gaji='"+months_years_string+"'";
						s2.execute(insert_2);
				}		
					
				}else if (month == 5) {
					r2 = s2.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO pengeluaran_gaji VALUES('"+months_years_string+"',"+"'"+get_total_gaji+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_total_gaji2 = r2.getInt("total_gaji"); // parse modal(modal_teb table) to int
						int pengeluran_gaji_final = get_total_gaji2 + get_total_gaji;
						String insert_2 = "UPDATE pengeluaran_gaji SET total_gaji='"+pengeluran_gaji_final+"' WHERE tanggal_gaji='"+months_years_string+"'";
						s2.execute(insert_2);
				}
					
				}else if (month == 6) {
					r2 = s2.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO pengeluaran_gaji VALUES('"+months_years_string+"',"+"'"+get_total_gaji+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_total_gaji2 = r2.getInt("total_gaji"); // parse modal(modal_teb table) to int
						int pengeluran_gaji_final = get_total_gaji2 + get_total_gaji;
						String insert_2 = "UPDATE pengeluaran_gaji SET total_gaji='"+pengeluran_gaji_final+"' WHERE tanggal_gaji='"+months_years_string+"'";
						s2.execute(insert_2);
				}	
					
				}else if (month == 7) {
					r2 = s2.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO pengeluaran_gaji VALUES('"+months_years_string+"',"+"'"+get_total_gaji+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_total_gaji2 = r2.getInt("total_gaji"); // parse modal(modal_teb table) to int
						int pengeluran_gaji_final = get_total_gaji2 + get_total_gaji;
						String insert_2 = "UPDATE pengeluaran_gaji SET total_gaji='"+pengeluran_gaji_final+"' WHERE tanggal_gaji='"+months_years_string+"'";
						s2.execute(insert_2);
				}	
										
				}else if (month == 8) {
					r2 = s2.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO pengeluaran_gaji VALUES('"+months_years_string+"',"+"'"+get_total_gaji+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_total_gaji2 = r2.getInt("total_gaji"); // parse modal(modal_teb table) to int
						int pengeluran_gaji_final = get_total_gaji2 + get_total_gaji;
						String insert_2 = "UPDATE pengeluaran_gaji SET total_gaji='"+pengeluran_gaji_final+"' WHERE tanggal_gaji='"+months_years_string+"'";
						s2.execute(insert_2);
				}	
									
				}else if (month == 9) {
					r2 = s2.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO pengeluaran_gaji VALUES('"+months_years_string+"',"+"'"+get_total_gaji+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_total_gaji2 = r2.getInt("total_gaji"); // parse modal(modal_teb table) to int
						int pengeluran_gaji_final = get_total_gaji2 + get_total_gaji;
						String insert_2 = "UPDATE pengeluaran_gaji SET total_gaji='"+pengeluran_gaji_final+"' WHERE tanggal_gaji='"+months_years_string+"'";
						s2.execute(insert_2);
				}	
					
				}else if (month == 10) {
					r2 = s2.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO pengeluaran_gaji VALUES('"+months_years_string+"',"+"'"+get_total_gaji+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_total_gaji2 = r2.getInt("total_gaji"); // parse modal(modal_teb table) to int
						int pengeluran_gaji_final = get_total_gaji2 + get_total_gaji;
						String insert_2 = "UPDATE pengeluaran_gaji SET total_gaji='"+pengeluran_gaji_final+"' WHERE tanggal_gaji='"+months_years_string+"'";
						s2.execute(insert_2);
				}	
					
				}else if (month == 11) {
					r2 = s2.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO pengeluaran_gaji VALUES('"+months_years_string+"',"+"'"+get_total_gaji+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_total_gaji2 = r2.getInt("total_gaji"); // parse modal(modal_teb table) to int
						int pengeluran_gaji_final = get_total_gaji2 + get_total_gaji;
						String insert_2 = "UPDATE pengeluaran_gaji SET total_gaji='"+pengeluran_gaji_final+"' WHERE tanggal_gaji='"+months_years_string+"'";
						s2.execute(insert_2);
				}	
					
				}else if (month == 12) {
					r2 = s2.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
	    			if (!r2.next()) {
						String insert_1 = "INSERT INTO pengeluaran_gaji VALUES('"+months_years_string+"',"+"'"+get_total_gaji+"')";
						s2.execute(insert_1);
	    			}else {
	    				int get_total_gaji2 = r2.getInt("total_gaji"); // parse modal(modal_teb table) to int
						int pengeluran_gaji_final = get_total_gaji2 + get_total_gaji;
						String insert_2 = "UPDATE pengeluaran_gaji SET total_gaji='"+pengeluran_gaji_final+"' WHERE tanggal_gaji='"+months_years_string+"'";
						s2.execute(insert_2);
				}				
				}    		
			}// WHILE
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void MOENY() {
		try {
	        // RETURN VALUE OBJECT DRIVER 
	        Class.forName(DRIVER);
	
	        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	        // c is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	        c = dm.getConnection(DB_URL, USER, PASS);
	
	        // buat objek statement
	        // s is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(createStatement) 
	        s = c.createStatement();
	        
	        // SET RESULTSET
	        r = s.executeQuery("SELECT * FROM modal_teb");
	        //
	        	
	        // FOR LAPORAN KEUANGAN
	        	// RETURN VALUE OBJECT DRIVER 
	        	Class.forName(DRIVER2);
		        
		        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
		        // c is a object from Conecctor class
		        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
		        c2 = dm2.getConnection(DB_URL2, USER2, PASS2);
		        
		        // buat objek statement
		        // s is a object from Conecctor class
		        //dm is object from Conecctor class that run the function(createStatement) 
		        s2 = c2.createStatement();	
		        	
		        // DELETE ALL ROWS
		        s2.executeUpdate("DELETE FROM laporan_keuangan");
	        
        	// FOR LAPORAN OMSET 
	        	Class.forName(DRIVER3);
	        	c3 = dm3.getConnection(DB_URL3, USER3, PASS3);
	        	s3 = c3.createStatement();	
	        	
	        // FOR LAPORAN OMSET 
	        	Class.forName(DRIVER4);
	        	c4 = dm4.getConnection(DB_URL4, USER4, PASS4);
	        	s4 = c4.createStatement();
	        	r4 = s4.executeQuery("SELECT * FROM gaji_karyawan");
	        	
	        
	        while (r.next()) { 		
        		// FEACTH VALUE FROM THE TABLE
				String get_modal_date = r.getString("date2"); 			// GET DATA FROM MODAL_TEB			
				int get_modal = Integer.valueOf(r.getString("modal")); 	// GET DATA FROM MODAL_TEB	
					
				// PARSE modal_date TO LOCAL DATE
				LocalDate get_modal_date_localdate = LocalDate.parse(get_modal_date);
					
				// GENERATOR VALUE OF MONTHS 1- 12
				int month = get_modal_date_localdate.getMonthValue();
					
				// CONVERT TO STRING
				DateTimeFormatter months_years = DateTimeFormatter.ofPattern("MM-YYYY"); // GENERATOR MM-YYYY FOR LOCALDATE
				String months_years_string = get_modal_date_localdate.format(months_years);
						
				if (month == 1) {
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (!r2.next()) {
						String empty = "";
						String input = "INSERT INTO laporan_keuangan VALUES('"+months_years_string+"','"+get_modal+"','"+empty+"','"+empty+"','"+empty+"')";
						s2.executeUpdate(input);
						
						// SET OMSET IN laporan_keuangan
						r3 = s3.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
						if (r3.next()) {
							String OMSET = String.valueOf(r3.getInt("omsett"));// PARSE OMSETT(OMSET) INT TO STRING
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}else if (!r3.next()) {
							int OMSET2 = 0;
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET2+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}
						
						//SET PENGELURAN GAJI laporan_keuangan
						r4 =s4.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
						if (r4.next()) {
							get_gaji = Integer.parseInt(r4.getString("total_gaji"));
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}else if (!r4.next()) {
							get_gaji=0;
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}
					}
					
					// PROFIT laporan_keuangan
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (r2.next()) {
						int get_modal_pendapatan = Integer.valueOf(r2.getString("modal"));
						int get_omset_pendapatan = Integer.valueOf(r2.getString("omset"));
						int profit_final = get_omset_pendapatan - get_modal_pendapatan - get_gaji;
						String profit_final2 = String.valueOf(profit_final);
						String updateE = "UPDATE laporan_keuangan SET profit ='"+profit_final2+"' WHERE date ='"+months_years_string+"'";
						s2.executeUpdate(updateE); // RUN STATMENT
					}
				}
				else if (month == 2) {
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (!r2.next()) {
						String empty = "";
						String input = "INSERT INTO laporan_keuangan VALUES('"+months_years_string+"','"+get_modal+"','"+empty+"','"+empty+"','"+empty+"')";
						s2.executeUpdate(input);
						
						r3 = s3.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
						if (r3.next()) {
							String OMSET = String.valueOf(r3.getInt("omsett"));// PARSE OMSETT(OMSET) INT TO STRING
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}else if (!r3.next()) {
							int OMSET2 = 0;
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET2+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}
						
						r4 =s4.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
						if (r4.next()) {
							get_gaji = Integer.parseInt(r4.getString("total_gaji"));
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}else if (!r4.next()) {
							get_gaji=0;
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}
					}
					
					// PROFIT
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (r2.next()) {
						int get_modal_pendapatan = Integer.valueOf(r2.getString("modal"));
						int get_omset_pendapatan = Integer.valueOf(r2.getString("omset"));
						int profit_final = get_omset_pendapatan - get_modal_pendapatan - get_gaji;
						String profit_final2 = String.valueOf(profit_final);
						String updateE = "UPDATE laporan_keuangan SET profit ='"+profit_final2+"' WHERE date ='"+months_years_string+"'";
						s2.executeUpdate(updateE); // RUN STATMENT
					}
				}
				else if (month == 3) {
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (!r2.next()) {
						String empty = "";
						String input = "INSERT INTO laporan_keuangan VALUES('"+months_years_string+"','"+get_modal+"','"+empty+"','"+empty+"','"+empty+"')";
						s2.executeUpdate(input);
						
						r3 = s3.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
						if (r3.next()) {
							String OMSET = String.valueOf(r3.getInt("omsett"));// PARSE OMSETT(OMSET) INT TO STRING
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}else if (!r3.next()) {
							int OMSET2 = 0;
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET2+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}
						
						r4 =s4.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
						if (r4.next()) {
							get_gaji = Integer.parseInt(r4.getString("total_gaji"));
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}else if (!r4.next()) {
							get_gaji=0;
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}
					}
					
					// PROFIT
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (r2.next()) {
						int get_modal_pendapatan = Integer.valueOf(r2.getString("modal"));
						int get_omset_pendapatan = Integer.valueOf(r2.getString("omset"));
						int profit_final = get_omset_pendapatan - get_modal_pendapatan - get_gaji;
						String profit_final2 = String.valueOf(profit_final);
						String updateE = "UPDATE laporan_keuangan SET profit ='"+profit_final2+"' WHERE date ='"+months_years_string+"'";
						s2.executeUpdate(updateE); // RUN STATMENT
					}
				}
				else if (month == 4) {
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (!r2.next()) {
						String empty = "";
						String input = "INSERT INTO laporan_keuangan VALUES('"+months_years_string+"','"+get_modal+"','"+empty+"','"+empty+"','"+empty+"')";
						s2.executeUpdate(input);
						
						r3 = s3.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
						if (r3.next()) {
							String OMSET = String.valueOf(r3.getInt("omsett"));// PARSE OMSETT(OMSET) INT TO STRING
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}else if (!r3.next()) {
							int OMSET2 = 0;
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET2+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}
						
						r4 =s4.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
						if (r4.next()) {
							get_gaji = Integer.parseInt(r4.getString("total_gaji"));
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}else if (!r4.next()) {
							get_gaji=0;
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}
					}
					
					// PROFIT
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (r2.next()) {
						int get_modal_pendapatan = Integer.valueOf(r2.getString("modal"));
						int get_omset_pendapatan = Integer.valueOf(r2.getString("omset"));
						int profit_final = get_omset_pendapatan - get_modal_pendapatan - get_gaji;
						String profit_final2 = String.valueOf(profit_final);
						String updateE = "UPDATE laporan_keuangan SET profit ='"+profit_final2+"' WHERE date ='"+months_years_string+"'";
						s2.executeUpdate(updateE); // RUN STATMENT
					}
				}
				else if (month == 5) {
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (!r2.next()) {
						String empty = "";
						String input = "INSERT INTO laporan_keuangan VALUES('"+months_years_string+"','"+get_modal+"','"+empty+"','"+empty+"','"+empty+"')";
						s2.executeUpdate(input);
						
						r3 = s3.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
						if (r3.next()) {
							String OMSET = String.valueOf(r3.getInt("omsett"));// PARSE OMSETT(OMSET) INT TO STRING
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}else if (!r3.next()) {
							int OMSET2 = 0;
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET2+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}
						
						r4 =s4.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
						if (r4.next()) {
							get_gaji = Integer.parseInt(r4.getString("total_gaji"));
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}else if (!r4.next()) {
							get_gaji=0;
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}
					}
					
					// PROFIT
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (r2.next()) {
						int get_modal_pendapatan = Integer.valueOf(r2.getString("modal"));
						int get_omset_pendapatan = Integer.valueOf(r2.getString("omset"));
						int profit_final = get_omset_pendapatan - get_modal_pendapatan - get_gaji;
						String profit_final2 = String.valueOf(profit_final);
						String updateE = "UPDATE laporan_keuangan SET profit ='"+profit_final2+"' WHERE date ='"+months_years_string+"'";
						s2.executeUpdate(updateE); // RUN STATMENT
					}
				}
				else if (month == 6) {
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (!r2.next()) {
						String empty = "";
						String input = "INSERT INTO laporan_keuangan VALUES('"+months_years_string+"','"+get_modal+"','"+empty+"','"+empty+"','"+empty+"')";
						s2.executeUpdate(input);
						
						r3 = s3.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
						if (r3.next()) {
							String OMSET = String.valueOf(r3.getInt("omsett"));// PARSE OMSETT(OMSET) INT TO STRING
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}else if (!r3.next()) {
							int OMSET2 = 0;
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET2+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}
						
						r4 =s4.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
						if (r4.next()) {
							get_gaji = Integer.parseInt(r4.getString("total_gaji"));
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}else if (!r4.next()) {
							get_gaji=0;
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}
					}
					
					// PROFIT
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (r2.next()) {
						int get_modal_pendapatan = Integer.valueOf(r2.getString("modal"));
						int get_omset_pendapatan = Integer.valueOf(r2.getString("omset"));
						int profit_final = get_omset_pendapatan - get_modal_pendapatan - get_gaji;
						String profit_final2 = String.valueOf(profit_final);
						String updateE = "UPDATE laporan_keuangan SET profit ='"+profit_final2+"' WHERE date ='"+months_years_string+"'";
						s2.executeUpdate(updateE); // RUN STATMENT
					}
				}
				else if (month == 7) {
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (!r2.next()) {
						String empty = "";
						String input = "INSERT INTO laporan_keuangan VALUES('"+months_years_string+"','"+get_modal+"','"+empty+"','"+empty+"','"+empty+"')";
						s2.executeUpdate(input);
						
						r3 = s3.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
						if (r3.next()) {
							String OMSET = String.valueOf(r3.getInt("omsett"));// PARSE OMSETT(OMSET) INT TO STRING
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}else if (!r3.next()) {
							int OMSET2 = 0;
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET2+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}
						
						r4 =s4.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
						if (r4.next()) {
							get_gaji = Integer.parseInt(r4.getString("total_gaji"));
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}else if (!r4.next()) {
							get_gaji=0;
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}
					}
					
					// PROFIT
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (r2.next()) {
						int get_modal_pendapatan = Integer.valueOf(r2.getString("modal"));
						int get_omset_pendapatan = Integer.valueOf(r2.getString("omset"));
						int profit_final = get_omset_pendapatan - get_modal_pendapatan - get_gaji;
						String profit_final2 = String.valueOf(profit_final);
						String updateE = "UPDATE laporan_keuangan SET profit ='"+profit_final2+"' WHERE date ='"+months_years_string+"'";
						s2.executeUpdate(updateE); // RUN STATMENT
					}
				}
				else if (month == 8) {
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (!r2.next()) {
						String empty = "";
						String input = "INSERT INTO laporan_keuangan VALUES('"+months_years_string+"','"+get_modal+"','"+empty+"','"+empty+"','"+empty+"')";
						s2.executeUpdate(input);
						
						r3 = s3.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
						if (r3.next()) {
							String OMSET = String.valueOf(r3.getInt("omsett"));// PARSE OMSETT(OMSET) INT TO STRING
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}else if (!r3.next()) {
							int OMSET2 = 0;
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET2+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}
						
						r4 =s4.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
						if (r4.next()) {
							get_gaji = Integer.parseInt(r4.getString("total_gaji"));
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}else if (!r4.next()) {
							get_gaji=0;
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}
					}
					
					// PROFIT
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (r2.next()) {
						int get_modal_pendapatan = Integer.valueOf(r2.getString("modal"));
						int get_omset_pendapatan = Integer.valueOf(r2.getString("omset"));
						int profit_final = get_omset_pendapatan - get_modal_pendapatan - get_gaji;
						String profit_final2 = String.valueOf(profit_final);
						String updateE = "UPDATE laporan_keuangan SET profit ='"+profit_final2+"' WHERE date ='"+months_years_string+"'";
						s2.executeUpdate(updateE); // RUN STATMENT
					}
				}
				else if (month == 9) {
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (!r2.next()) {
						String empty = "";
						String input = "INSERT INTO laporan_keuangan VALUES('"+months_years_string+"','"+get_modal+"','"+empty+"','"+empty+"','"+empty+"')";
						s2.executeUpdate(input);
						
						r3 = s3.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
						if (r3.next()) {
							String OMSET = String.valueOf(r3.getInt("omsett"));// PARSE OMSETT(OMSET) INT TO STRING
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}else if (!r3.next()) {
							int OMSET2 = 0;
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET2+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}
						
						r4 =s4.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
						if (r4.next()) {
							get_gaji = Integer.parseInt(r4.getString("total_gaji"));
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}else if (!r4.next()) {
							get_gaji=0;
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}
					}
					
					// PROFIT
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (r2.next()) {
						int get_modal_pendapatan = Integer.valueOf(r2.getString("modal"));
						int get_omset_pendapatan = Integer.valueOf(r2.getString("omset"));
						int profit_final = get_omset_pendapatan - get_modal_pendapatan - get_gaji;
						String profit_final2 = String.valueOf(profit_final);
						String updateE = "UPDATE laporan_keuangan SET profit ='"+profit_final2+"' WHERE date ='"+months_years_string+"'";
						s2.executeUpdate(updateE); // RUN STATMENT
					}
				}
				else if (month == 10) {
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (!r2.next()) {
						String empty = "";
						String input = "INSERT INTO laporan_keuangan VALUES('"+months_years_string+"','"+get_modal+"','"+empty+"','"+empty+"','"+empty+"')";
						s2.executeUpdate(input);
						
						r3 = s3.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
						if (r3.next()) {
							String OMSET = String.valueOf(r3.getInt("omsett"));// PARSE OMSETT(OMSET) INT TO STRING
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}else if (!r3.next()) {
							int OMSET2 = 0;
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET2+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}
						
						r4 =s4.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
						if (r4.next()) {
							get_gaji = Integer.parseInt(r4.getString("total_gaji"));
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}else if (!r4.next()) {
							get_gaji=0;
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}
					}
					
					// PROFIT
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (r2.next()) {
						int get_modal_pendapatan = Integer.valueOf(r2.getString("modal"));
						int get_omset_pendapatan = Integer.valueOf(r2.getString("omset"));
						int profit_final = get_omset_pendapatan - get_modal_pendapatan - get_gaji;
						String profit_final2 = String.valueOf(profit_final);
						String updateE = "UPDATE laporan_keuangan SET profit ='"+profit_final2+"' WHERE date ='"+months_years_string+"'";
						s2.executeUpdate(updateE); // RUN STATMENT
					}
				}
				else if (month == 11) {
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (!r2.next()) {
						String empty = "";
						String input = "INSERT INTO laporan_keuangan VALUES('"+months_years_string+"','"+get_modal+"','"+empty+"','"+empty+"','"+empty+"')";
						s2.executeUpdate(input);
						
						r3 = s3.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
						if (r3.next()) {
							String OMSET = String.valueOf(r3.getInt("omsett"));// PARSE OMSETT(OMSET) INT TO STRING
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}else if (!r3.next()) {
							int OMSET2 = 0;
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET2+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}
						
						r4 =s4.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
						if (r4.next()) {
							get_gaji = Integer.parseInt(r4.getString("total_gaji"));
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}else if (!r4.next()) {
							get_gaji=0;
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}
					}
					
					// PROFIT
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (r2.next()) {
						int get_modal_pendapatan = Integer.valueOf(r2.getString("modal"));
						int get_omset_pendapatan = Integer.valueOf(r2.getString("omset"));
						int profit_final = get_omset_pendapatan - get_modal_pendapatan - get_gaji;
						String profit_final2 = String.valueOf(profit_final);
						String updateE = "UPDATE laporan_keuangan SET profit ='"+profit_final2+"' WHERE date ='"+months_years_string+"'";
						s2.executeUpdate(updateE); // RUN STATMENT
					}
				}
				else if (month == 12) {
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (!r2.next()) {
						String empty = "";
						String input = "INSERT INTO laporan_keuangan VALUES('"+months_years_string+"','"+get_modal+"','"+empty+"','"+empty+"','"+empty+"')";
						s2.executeUpdate(input);
						
						r3 = s3.executeQuery("SELECT * FROM omset WHERE date_omset='"+months_years_string+"'");
						if (r3.next()) {
							String OMSET = String.valueOf(r3.getInt("omsett"));// PARSE OMSETT(OMSET) INT TO STRING
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}else if (!r3.next()) {
							int OMSET2 = 0;
							String input2 = "UPDATE laporan_keuangan SET omset='"+OMSET2+"' WHERE date='"+months_years_string+"'";
							s3.executeUpdate(input2); // RUN MYSQL STATMENT 
						}
						
						r4 =s4.executeQuery("SELECT * FROM pengeluaran_gaji WHERE tanggal_gaji='"+months_years_string+"'");
						if (r4.next()) {
							get_gaji = Integer.parseInt(r4.getString("total_gaji"));
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}else if (!r4.next()) {
							get_gaji=0;
							String input3 = "UPDATE laporan_keuangan SET gaji='"+get_gaji+"' WHERE date='"+months_years_string+"'";
							s4.executeUpdate(input3); // RUN MYSQL STATMENT 
						}
					}
					
					// PROFIT
					r2 = s2.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+months_years_string+"'");
					if (r2.next()) {
						int get_modal_pendapatan = Integer.valueOf(r2.getString("modal"));
						int get_omset_pendapatan = Integer.valueOf(r2.getString("omset"));
						int profit_final = get_omset_pendapatan - get_modal_pendapatan - get_gaji;
						String profit_final2 = String.valueOf(profit_final);
						String updateE = "UPDATE laporan_keuangan SET profit ='"+profit_final2+"' WHERE date ='"+months_years_string+"'";
						s2.executeUpdate(updateE); // RUN STATMENT
					}
				}
        	}
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// method for table view
	public ObservableList<Pendapatan> list_data(){ // non void method, to get data from database and set to observableArrayList()
		ObservableList<Pendapatan> data =FXCollections.observableArrayList();// container for the data
		try {
	        // RETURN VALUE OBJECT DRIVER 
	        Class.forName(DRIVER);
	
	        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	        // c is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	        c = dm.getConnection(DB_URL, USER, PASS);
	
	        // buat objek statement
	        // s is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(createStatement) 
	        s = c.createStatement();
	        
	        // difine Resultset as statment to exucute query to suppliers table
	        // r is Resultset object
	        r = s.executeQuery("SELECT * FROM laporan_keuangan");
	        	        
	        while (r.next()) {
	        	// LOCAL VARIABLE
        		Double currency = new Double(r.getString("modal")); 
        		Double currency2 = new Double(r.getString("omset")); 
        		Double currency3 = new Double(r.getString("gaji")); 
        		Double currency4 = new Double(r.getString("profit")); 
        		String currencyOut,currencyOut2,currencyOut3,currencyOut4;
        		
	        	NumberFormat currencyFormatter; // OBJECT OF NUMBERFORMAT CLASS 				            
	            Locale s = new Locale("id", "ID");// OBJECT OF LOCALE		            
	            currencyFormatter = NumberFormat.getCurrencyInstance(s); // RUN METHOD 		            
	            currencyOut = currencyFormatter.format(currency); // RUN METHOD
	            currencyOut2 = currencyFormatter.format(currency2); // RUN METHOD
	            currencyOut3 = currencyFormatter.format(currency3); // RUN METHOD
	            currencyOut4 = currencyFormatter.format(currency4); // RUN METHOD
	        	
	        	// get data from database and set constructor of suppliers class
	        	Pendapatan pendapatan_object = new Pendapatan(r.getString("date"),currencyOut,currencyOut2,currencyOut3,currencyOut4);
	        	data.add(pendapatan_object);// set data object to get data from admin object 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data; // return ObservableListvalue			
	} 
	
	// method to show data to the table
		public void show_data(){
			try {
				ObservableList<Pendapatan> list = list_data(); // create ObservableList object and run list_data method 
				table.setItems(list); // set data of ObservableList<Karyawan> to the table
				tanggal_col.setCellValueFactory(new PropertyValueFactory<Pendapatan, String>("Date"));// display value to the column 
				modal_col.setCellValueFactory(new PropertyValueFactory<Pendapatan, String>("Modal"));// display value to the column 
				omset_col.setCellValueFactory(new PropertyValueFactory<Pendapatan, String>("Omset"));// display value to the column 
				p_gaji_col.setCellValueFactory(new PropertyValueFactory<Pendapatan, String>("Gaji"));// display value to the column 		
				profit_col.setCellValueFactory(new PropertyValueFactory<Pendapatan, String>("Profit"));// display value to the column 	
			} 	
			catch (Exception e) {				
				System.out.print("show data is error");
				e.printStackTrace();
			}
		}	// method to show data to the table
	
	// method to search data
	public void search_data() {
		ObservableList<Pendapatan> search_data = FXCollections.observableArrayList();
		try {
            // RETURN VALUE OBJECT DRIVER 
            Class.forName(DRIVER);

            // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
            // c is a object from Conecctor class
            //dm is object from Conecctor class that run the function(getConnection) and set the parameters
            c = dm.getConnection(DB_URL, USER, PASS);

            // buat objek statement
            // s is a object from Conecctor class
            //dm is object from Conecctor class that run the function(createStatement) 
            s = c.createStatement();
            
            String get_search_field = search_field.getText();
            
            r = s.executeQuery("SELECT * FROM laporan_keuangan WHERE date='"+get_search_field+"'");           
            while (r.next()) {
            	
            	// LOCAL VARIABLE
        		Double currency = new Double(r.getString("modal")); 
        		Double currency2 = new Double(r.getString("omset")); 
        		Double currency3 = new Double(r.getString("gaji")); 
        		Double currency4 = new Double(r.getString("profit")); 
        		String currencyOut,currencyOut2,currencyOut3,currencyOut4;
        		
	        	NumberFormat currencyFormatter; // OBJECT OF NUMBERFORMAT CLASS 				            
	            Locale s = new Locale("id", "ID");// OBJECT OF LOCALE		            
	            currencyFormatter = NumberFormat.getCurrencyInstance(s); // RUN METHOD 		            
	            currencyOut = currencyFormatter.format(currency); // RUN METHOD
	            currencyOut2 = currencyFormatter.format(currency2); // RUN METHOD
	            currencyOut3 = currencyFormatter.format(currency3); // RUN METHOD
	            currencyOut4 = currencyFormatter.format(currency4); // RUN METHOD
	        	
	        	// get data from database and set constructor of suppliers class
	        	Pendapatan pendapatan_object = new Pendapatan(r.getString("date"),currencyOut,currencyOut2,currencyOut3,currencyOut4);
	        	search_data.add(pendapatan_object);// set data object to get data from admin object                 
            }
            			
			table.setItems(search_data); // set data of ObservableList<Admin> to the table 
			tanggal_col.setCellValueFactory(new PropertyValueFactory<Pendapatan, String>("Date"));// display value to the column 
			modal_col.setCellValueFactory(new PropertyValueFactory<Pendapatan, String>("Modal"));// display value to the column 
			omset_col.setCellValueFactory(new PropertyValueFactory<Pendapatan, String>("Omset"));// display value to the column 
			p_gaji_col.setCellValueFactory(new PropertyValueFactory<Pendapatan, String>("Gaji"));// display value to the column 		
			profit_col.setCellValueFactory(new PropertyValueFactory<Pendapatan, String>("Profit"));// display value to the column 			
		} catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	// method to create pdf
	public void Create_pdf() {
		 try {                      
	            // RETURN VALUE OBJECT DRIVER 
	            Class.forName(DRIVER);

	            // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	            // c is a object from Conecctor class
	            //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	            c = dm.getConnection(DB_URL, USER, PASS);

	            // buat objek statement
	            // s is a object from Conecctor class
	            //dm is object from Conecctor class that run the function(createStatement) 
	            s = c.createStatement();
	           
	            //String search_pdf = search.getText();// get String 
	            
	            // set location 
	            r = s.executeQuery("SELECT * FROM laporan_keuangan");
	            
	            // Initialize PDF document
	            PdfDocument pdf = new PdfDocument(new PdfWriter(location));                  
	           
	            // Creating a Document object       
	            Document doc = new Document(pdf);
	            
	          //CREATING AN IMAGETAE OBJECT
  			String imFile = "C:\\Users\\Fajar\\eclipse-workspace\\Skripsi\\src\\images\\logo.png";
  			ImageData data = ImageDataFactory.create(imFile);
  		//
  
  		// CREATING AN IMAGE OBJECT
  			Image image = new Image(data).setHeight(50).setWidth(50).setFixedPosition(270, 765);
  		//
	            
	             // Creating a table 
	            float [] pointColumnWidths = {150F,150F,150F,150F,150F};  
	            Table table = new Table(pointColumnWidths);
	            table.setRelativePosition(0, 150, 0, 0);
	            
	            //add font object
	            PdfFont bold = PdfFontFactory.createFont(StandardFonts.TIMES_BOLD);
	            
	         // adding cells to the table
      		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("TANGGAL").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("MODAL").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("OMSET").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("PENGELUARAN GAJI").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("PROFIT").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      	//
	            
	            while (r.next()) {
	            
	            // DEFINE LOCAL VARIABLE 
	            String A = r.getString("date");
	            String B = r.getString("modal");
	            String C = r.getString("omset");
	            String D = r.getString("gaji");
	            String E = r.getString("profit");
	            
	            // Adding cells to the table
	            table.addCell(new Cell().add(new Paragraph(A).setFontSize(8)));
	            table.addCell(new Cell().add(new Paragraph(B).setFontSize(8))); 
	            table.addCell(new Cell().add(new Paragraph(C).setFontSize(8))); 
	            table.addCell(new Cell().add(new Paragraph(D).setFontSize(8)));
	            table.addCell(new Cell().add(new Paragraph(E).setFontSize(8))); 
	            }
	            
	         // HEADER
	            Text title2 = new Text("TB CHANDRA")
	            	.setFont(PdfFontFactory.createFont(StandardFonts.HELVETICA))
	        		.setFontSize(11).setBold();
	            Text title3 = new Text("Jl. Kemang, Sukatani, Kec. Tapos, Kota Depok, Jawa Barat 16454")
	            	.setFont(PdfFontFactory.createFont(StandardFonts.HELVETICA))
	            	.setFontSize(9);
	            Paragraph header = new Paragraph(title2);
	            Paragraph header2 = new Paragraph(title3);
	        //
          
          // set the text to the document
      		Text line = new Text("============================================================================");
      		Text title4 = new Text("LAPORAN KEUANGAN").setBold().setFontSize(12);  
      		Paragraph Line = new Paragraph(line);
      		Paragraph paragraph = new Paragraph(title4);
      		
      		LocalDate pdfdate = LocalDate.now();
      		String name = "";
      		String ind_date = pdfdate.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL));
     		Paragraph currenttime2 = new Paragraph("Depok, "+ind_date + " \n  Direktur \n \n \n  (Chandra Kurniawan)").setRelativePosition(170, 180, 0, 0);
      		currenttime2.setTextAlignment(TextAlignment.CENTER);
      	//
      		doc.add(image);
      		doc.add(table);
      		doc.add(currenttime2);
      		
          for (int i = 1; i <= pdf.getNumberOfPages(); i++) { // LOOP FOOTER FOR EACH PAGE
				Rectangle dd = pdf.getPage(i).getPageSize(); // GET PAGE NUMBER 
				
				float x = dd.getWidth() / 2;
				float y = dd.getTop() - 100;
				
				float x2 = dd.getWidth() / 2;
				float y2 = dd.getTop() - 125;
				
				float x3 = dd.getWidth() / 2;
				float y3 = dd.getTop() - 145;
				
				float x4 = dd.getWidth() / 2;
				float y4 = dd.getTop() - 165;
				
				float x5 = dd.getWidth() / 2;
				float y5 = dd.getTop() - 185;
							
				doc.showTextAligned(header,x, y, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
				doc.showTextAligned(header2,x2, y2, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);        
				doc.showTextAligned(Line,x3,y3, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
				doc.showTextAligned(paragraph,x4, y4, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
				doc.showTextAligned(Line,x5,y5, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);								
			}
          //	            
	            // notif
	            text =" Pdf Telah Dibuat";	// set Main class variable
	            Main_class.login(); 	// run Main class method
	            doc.close();	// close document         
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		}
		// method to create pdf
		
}
