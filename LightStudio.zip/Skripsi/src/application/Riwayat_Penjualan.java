package application;

public class Riwayat_Penjualan {
    // class variable
		private String 	ID_PENJUALAN,RIWAYAT_PENJUALAN,HARGA_TOTAL,TANGGAL_TRANSAKSI;
	//
	
	public Riwayat_Penjualan (String id_penjualan, String riwayat_penjualan, String harga_total, String tanggal_transaksi) {
		this.ID_PENJUALAN = id_penjualan;
		this.RIWAYAT_PENJUALAN = riwayat_penjualan;
		this.HARGA_TOTAL = harga_total;
		this.TANGGAL_TRANSAKSI = tanggal_transaksi;
	}
	public String getId_Penjualan() {
		return ID_PENJUALAN;
	}
	public String getRiwayat_Penjualan() {
		return RIWAYAT_PENJUALAN;
	}
	public String getHarga_Total() {
		return HARGA_TOTAL;
	}
	public String getTanggal_Transaksi() {
		return TANGGAL_TRANSAKSI;
	}
}
