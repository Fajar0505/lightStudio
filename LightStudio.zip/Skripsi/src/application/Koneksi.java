package application;

import java.sql.*;

public class Koneksi {
	// class atribut
    // final = Attributes and methods cannot be overridden/modified
    // static = Attributes and methods belongs to the class
    static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/tb_chandra";
    static final String USER ="root";
    static final String PASS ="";

    // create class object for mysql class
    static Connection c; //Connection is a class to create conection
    static Statement s;  // Statement is to accsess mysql quary
    static ResultSet r; // to set result from quary mysql   
    static DriverManager dm; // DriverManager is a class for database driver
    
    // define final variable as com.mysql.jdbc.Driver
    // static = the atributs belong to object of the variable 
    static final String DRIVER2= "com.mysql.cj.jdbc.Driver";
    static final String DB_URL2 = "jdbc:mysql://localhost/tb_chandra";
    static final String USER2 ="root";
    static final String PASS2 ="";

    // create class object for mysql class
    static Connection c2; //Connection is a class to create conection
    static Statement s2;  // Statement is to accsess mysql quary
    static ResultSet r2; // to set result from quary mysql   
    static DriverManager dm2; // DriverManager is a class for database driver
    
    // class atribut
    // define final variable as com.mysql.jdbc.Driver
    // static = the atributs belong to object of the variable 
    static final String DRIVER3= "com.mysql.cj.jdbc.Driver";
    static final String DB_URL3 = "jdbc:mysql://localhost/tb_chandra";
    static final String USER3 ="root";
    static final String PASS3 ="";

    // create class object for mysql class
    static Connection c3; //Connection is a class to create conection
    static Statement s3;  // Statement is to accsess mysql quary
    static ResultSet r3; // to set result from quary mysql   
    static DriverManager dm3; // DriverManager is a class for database driver
    
    // class atribut
    // define final variable as com.mysql.jdbc.Driver
    // static = the atributs belong to object of the variable 
    static final String DRIVER4= "com.mysql.cj.jdbc.Driver";
    static final String DB_URL4 = "jdbc:mysql://localhost/tb_chandra";
    static final String USER4 ="root";
    static final String PASS4 ="";

    // create class object for mysql class
    static Connection c4; //Connection is a class to create conection
    static Statement s4;  // Statement is to accsess mysql quary
    static ResultSet r4; // to set result from quary mysql   
    static DriverManager dm4; // DriverManager is a class for database driver
}
