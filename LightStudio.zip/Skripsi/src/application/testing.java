package application;


import static application.Koneksi.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class testing {
	public static void main(String[] args) {
	    
	    Connection connection = null;
	      String url = "jdbc:mysql://localhost:3306/";
	      String dbName = "tb_chandra";
	      String driverName = "com.mysql.cj.jdbc.Driver";
	      String userName = "root";
	      String password = "";
	      try{
	        Class.forName(DRIVER);
	        c = dm.getConnection(DB_URL, USER, PASS);
	        s = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
	        r = s.executeQuery("SELECT * FROM suplier");    
	        r.last();
	          
	          System.out.println("User Name :" + r.getString("NAMA"));  
	          System.out.println(r.getRow());
//	        try{
//	          Statement stmt = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
//	          String selectquery = "select NAMA from suplier";
//	          ResultSet rs = stmt.executeQuery(selectquery);
//	          
//	          rs.last();
//	          
//	          System.out.println("User Name :" + rs.getString("NAMA"));  
//	          System.out.println(rs.getRow());
//	        }
//	        catch(SQLException s){
//	          System.out.println(s);
//	        }
//	        connection.close();
	      }
	      catch (Exception e){
	        e.printStackTrace();
	      }  
	  }
}
