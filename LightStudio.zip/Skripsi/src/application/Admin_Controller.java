package application;

//IMPORT ATTRIBUTES FROM MY OWN CLASS
import static application.Koneksi.*;
import static application.Main.*;
import static application.Login_Controller.*;

import java.net.URL;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ResourceBundle;

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.VerticalAlignment;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class Admin_Controller implements Initializable {
	// location to save pdf file
	static final String location = "C:\\Users\\Fajar\\Documents\\Light Studio\\Report\\admin pdf.pdf";
	// Create Object for Main Class
	Main Main_class = new Main(); 
	// Class Variable
	static String Kode;
	static String status_options="";
	static String kelamin_options="";
	
	//  FXML CODES AREA
	@FXML
	private Label username,status;
	@FXML
	private Button pembelian_btn,barang_btn,penjualan_btn,gaji_karyawan_btn,pendapatan_btn,update_btn,show_btn,
	suplier_btn,karyawan_btn,admin_btn,keluar_btn,search_btn,pdf_button,input_btn,hapus_btn,delete_btn;
	@FXML
	private TableView<Admin> table;
	@FXML
	private TableColumn<Admin, String> Id_col,username_col,password_col,alamat_col,no_col,Status_col;
	@FXML
	private TextField id_field,username_field,alamat_field,kontak_field,search_field;
	@FXML
	private PasswordField password_field;
	@FXML
	private ComboBox<String> status_combobox2;
	
	// Over Write Method 
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		status_combobox2.getItems().add("DIREKTUR");
		status_combobox2.getItems().add("KARYAWAN");
	}
	
	//Methos For Buttons of FXML File
	public void Button_Action(ActionEvent event) {
		if (event.getSource() == penjualan_btn) {
			Direktur_Controller Direktur_Controller_Object = fxml_file2.getController(); // Object Controller Class		
			// Run Method From Other Controllers
			Direktur_Controller_Object.show_name();
			Direktur_Controller_Object.show_data();			
			window.setScene(layer_in_stage2); //Move to Penjualan Page
		}else if (event.getSource() == barang_btn) {
			Barang_Controller Barang_Controller_Object = fxml_file10.getController();	
			Barang_Controller_Object.show_name();// Run Method From Other Controllers
			Barang_Controller_Object.show_data();
			window.setScene(layer_in_stage10); //Move to Barang Page
		}else if (event.getSource() == pembelian_btn) {
			Pembelian_Controller Pembelian_Controller_Object = fxml_file9.getController();	
			Pembelian_Controller_Object.show_name();// Run Method From Other Controllers
			Pembelian_Controller_Object.show_data();
			window.setScene(layer_in_stage9); //Move to Pembelian Page
		}else if (event.getSource() == gaji_karyawan_btn) {
			Gaji_Controller Gaji_Controller_Object = fxml_file8.getController();	
			Gaji_Controller_Object.show_name();// Run Method From Other Controllers
			Gaji_Controller_Object.show_data();
			window.setScene(layer_in_stage8); //Move to Gaji Page
		}else if (event.getSource() == pendapatan_btn) {
			Pendapatan_Controller Pendapatan_Controller_Object = fxml_file12.getController();
			Pendapatan_Controller_Object.MODAL(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.PENGELUARAN_GAJI(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.OMSET(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.MOENY(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.show_data(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.show_name(); // RUN METHOD FROM OTHER CONTROLLER
			window.setScene(layer_in_stage12); //Move to Pendapatan Page
		}else if (event.getSource() == suplier_btn) {
			// Object Controller Class
			Suplier_Controller Suplier_Controller_Object = fxml_file5.getController();	
			Suplier_Controller_Object.show_name();// Run Method From Other Controllers
			Suplier_Controller_Object.show_data();	
			window.setScene(layer_in_stage5); //Move to Suplier Page
		}else if (event.getSource() == karyawan_btn) {
			// Object Controller Class
			Karyawan_Controller Karyawan_Controller_Object = fxml_file6.getController();	
			Karyawan_Controller_Object.show_name();// Run Method From Other Controllers
			Karyawan_Controller_Object.show_data();// Run Method From Other Controllers
			window.setScene(layer_in_stage6); //Move to Karyawan Page			
		}else if (event.getSource() == admin_btn) {
			// Object Controller Class
			Admin_Controller Admin_Controller_Object = fxml_file7.getController();	
			Admin_Controller_Object.show_name();// Run Method From Other Controllers
			Admin_Controller_Object.show_data();// Run Method From Other Controllers
			window.setScene(layer_in_stage7); //Move to Admin Page
		}else if (event.getSource() == keluar_btn) {
			window.setX(350);
			window.setY(170);
			window.setScene(layer_in_stage);
			login_username =""; 
		}
		else if (event.getSource() == search_btn) {
			search_data();
		}
		else if (event.getSource() == pdf_button) {
			Create_pdf(); 
		}
		else if (event.getSource() == input_btn) {
			input_data();  
		}
		else if (event.getSource() == hapus_btn) {
			clear_textfield(); // run method
		}
		else if (event.getSource() == delete_btn) {
			delete(); // run method
		}else if (event.getSource() == update_btn) {
			update(); // run method
		}else if (event.getSource() == show_btn) {
			show(); // run method
		}
	}
	
	// ComboBox Method
	public void CHOICE(ActionEvent event) { // method to get value of ComboBox
			status_combobox2.getSelectionModel().getSelectedItem();
		    status_options = status_combobox2.getValue();// set variable status_options as value of ComboBox
	}
				
	//method to show admin's name
	public void show_name() { 
		username.setText(login_username);
		status.setText(index);
	}
	
	// method for table view
	public ObservableList<Admin> list_data(){ // non void method, to get data from database and set to observableArrayList()
		ObservableList<Admin> data =FXCollections.observableArrayList();// container for the data
		try {
	        // RETURN VALUE OBJECT DRIVER 
	        Class.forName(DRIVER);
	
	        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	        // c is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	        c = dm.getConnection(DB_URL, USER, PASS);
	
	        // buat objek statement
	        // s is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(createStatement) 
	        s = c.createStatement();
	        
	        // difine Resultset as statment to exucute query to suppliers table
	        // r is Resultset object
	        r = s.executeQuery("SELECT * FROM admin");
	        	        
	        while (r.next()) {
	        	// get data from database and set constructor of suppliers class
	        	Admin admin_object = new Admin(r.getString("id_admin"),r.getString("username"),"********",r.getString("alamat"),r.getString("no_hp"),r.getString("status"));
	        	data.add(admin_object);// set data object to get data from admin object 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data; // return ObservableListvalue			
	} 
	
	// method to show data to the table
	public void show_data(){
		try {
			ObservableList<Admin> list = list_data(); // create ObservableList object and run list_data method 
			table.setItems(list); // set data of ObservableList<Karyawan> to the table
			Id_col.setCellValueFactory(new PropertyValueFactory<Admin, String>("Id_output"));// display value to the column 
			username_col.setCellValueFactory(new PropertyValueFactory<Admin, String>("Username_output"));// display value to the column 
			password_col.setCellValueFactory(new PropertyValueFactory<Admin, String>("Password_output"));// display value to the column 
			alamat_col.setCellValueFactory(new PropertyValueFactory<Admin, String>("Alamat_output"));// display value to the column 
			no_col.setCellValueFactory(new PropertyValueFactory<Admin, String>("No_hp_output"));// display value to the column 
			Status_col.setCellValueFactory(new PropertyValueFactory<Admin, String>("Status_output"));// display value to the column			
		} 	
		catch (Exception e) {				
			System.out.print("show data is error");
			e.printStackTrace();
		}
	}	// method to show data to the table
	
	// Delete Method
	public void delete() {
		if (table.getSelectionModel().isSelected(table.getSelectionModel().getSelectedIndex())) {
			Admin selected_item = table.getSelectionModel().getSelectedItem();
		      try {
		      // RETURN VALUE OBJECT DRIVER 
		      Class.forName(DRIVER);
		
		      // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
		      // c is a object from Conecctor class
		      //dm is object from Conecctor class that run the function(getConnection) and set the parameters
		      c = dm.getConnection(DB_URL, USER, PASS);
		
		      // buat objek statement
		      // s is a object from Conecctor class
		      //dm is object from Conecctor class that run the function(createStatement) 
		      s = c.createStatement();
		      r = s.executeQuery("SELECT * FROM admin WHERE id_admin='"+selected_item.getId_output()+"'");
		      if (r.next()) {
		          s.executeUpdate("DELETE FROM admin WHERE id_admin='"+selected_item.getId_output()+"'");
		          text = selected_item.getId_output()+" HAS DELETED"; // set Main class variable
		          Main_class.login(); // run method from Main class
		          clear_textfield(); // run method
		          show_data(); // run method
		      }
		      else{
		      	text = "THE ID WAS NOT FOUND"; // set Main class variable
		      	Main_class.login(); // run method from Main class 
		          clear_textfield(); // run method
		      }
		  }
		  catch (Exception e) {
		      e.printStackTrace();
		  }
		}
		else {
			text ="Baris Table Belum Di Pilih";
			Main_class.login();
		}
	}
	
	// method to check a variable is numeric or not
	public static boolean isNumeric(String str) { 
        return str != null && str.matches("[-+]?\\d*\\.?\\d+");
    }
		
	// method to input data to the database
    public void input_data() { 	   	
    	// method variable
        String id = id_field.getText();
        String username = username_field.getText();
        String password = password_field.getText();
        String alamat = alamat_field.getText();
        String kontak = kontak_field.getText();
        String status = status_options;
	                	
        try {            	                            
        	Class.forName(DRIVER);
 	        c = dm.getConnection(DB_URL, USER, PASS);
 	        s = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
 	        r = s.executeQuery("SELECT * FROM admin WHERE id_admin ='"+id+"'");    
 	       if (r.next()) {
               	text ="ID ADMIN SUDAH TERDAFTAR"; // set Main class variable
               	Main_class.login();// run method from Main class
 	       }
 	       else {
 	    	   //Count Characters of The variable
               int id_lenght = id.length(); 
               int username_lenght = username.length();
               int password_lenght = password.length(); 
               int alamat_lenght = alamat.length(); 
               int kontak_lenght = kontak.length();
               int status_lenght = status.length(); 
               
			   // define the text field
			   if (id_lenght == 0) {  
				   text ="ID ADMIN TIDAK BOLEH KOSOSNG"; // set Main class variable
				   Main_class.login();// run method from Main class
			   }
				   else if (id_lenght > 50) {
					   text ="JUMLAH KARAKTER ID ADMIN MELEBIHI 50 KATA"; // set Main class variable
					   Main_class.login();// run method from Main class
				   }
				   else if (isNumeric(id) == false) {
					   text ="ID ADMIN TIDAK BOLEH MENGANDUNG ALFABET"; // set Main class variable
					   Main_class.login();	// run method from Main class
				   } 
	               
	               // define the text field
	               else if (username_lenght == 0) {  
	            	   text ="USERNAME TIDAK BOLEH KOSOSNG"; // set Main class variable
	            	   Main_class.login();// run method from Main class
	               }
	               else if (username_lenght > 50) {
	           			text ="JUMLAH KARAKTER USERNAME MELEBIHI 50 KATA"; // set Main class variable
	           			Main_class.login();// run method from Main class
	               }
	               else if (isNumeric(username) == true) {
	   					text ="USERNAME TIDAK BOLEH MENGANDUNG ANGKA"; // set Main class variable
	   					Main_class.login();	// run method from Main class
	               }
	               
	               // define the field
	               else if (password_lenght == 0) {
	               		text = "PASSWORD TIDAK BOLEH KOSOSNG"; // set Main class variable
	               		Main_class.login();// run method from Main class
	               }
	               else if (password_lenght > 50) {
	   					text ="JUMLAH KARAKTER PASSWORD MELEBIHI 50 KATA"; // set Main class variable
	   					Main_class.login();// run method from Main class
	               }
	               
	               // define the field
	               else if (alamat_lenght == 0) {
	               		text = "ALAMAT TIDAK BOLEH KOSOSNG"; // set Main class variable
	               		Main_class.login();// run method from Main class
	               }else if (alamat_lenght > 150) {
	               		text ="JUMLAH KARAKTER ALAMAT MELEBIHI 150 KATA"; // set Main class variable
	               		Main_class.login();// run method from Main class
	               }
	               
	               
	               // define the text field of no hp
	               else if (kontak_lenght == 0) {
	               		text ="TELEPON TIDAK BOLEH KOSONG"; // set Main class variable
	               		Main_class.login();// run method from Main class
	               }
	               else if (kontak_lenght < 11) {
	   					text = "TELEPON KURANG DARI 11 KARAKTER"; // set Main class variable
	   					Main_class.login();// run method from Main class
	               }
	               else if (kontak_lenght > 13) {
	               		text ="TELEPON LEBIH DARI 13 KARAKTER"; // set Main class variable
	               		Main_class.login();// run method from Main class
	               }
	               else if (isNumeric(kontak) == false) {
	               		text ="TELEPON HARUS MENGGUNAKAN ANGKA"; // set Main class variable
	               		Main_class.login();	// run method from Main class
	               }
	               
	               // define the text field 
	               else if (status_lenght == 0) {
	               		text ="STATUS TIDAK BOLEH KOSONG"; // set Main class variable
	               		Main_class.login();// run method from Main class          	
	               }
	               else if (status_lenght > 50) {
	               		text ="JUMLAH KARAKTER STATUS MELEBIHI 50 KATA"; // set Main class variable
	               		Main_class.login();// run method from Main class
	               }	     	                  	        
			   
     	       else {
					//convert method variable to uppercase
					String username_uppercase = username.toUpperCase();
					String alamat_uppercase = alamat.toUpperCase();
					String kontak_uppercase = kontak.toUpperCase();
					String status_uppercase = status.toUpperCase();
					//    
     	               
     	             String insert ="INSERT INTO admin VALUES"+"('"+id+"',"+"'"+username_uppercase+"',"+"'"+password+"',"+"'"+alamat_uppercase+"',"+"'"+kontak_uppercase+"','"+status_uppercase+"')";
     	             s.execute(insert);
     	             text = "DATA TELAH DI INPUT";	// set Main class variable
     	             Main_class.login();				// run method from Main class
     	             show_data(); 					// run method                    
     	             clear_textfield();	
 	 	       } 
 	       }   
        } //try 
        catch (Exception e) {
            e.printStackTrace();
        }
	} // end of method to input data to the database
     
    // Update Method
    public void update() {
    		        	
    	// method variable  	
    	String id = id_field.getText();
        String username = username_field.getText();
        String password = password_field.getText();
        String alamat = alamat_field.getText();
        String kontak = kontak_field.getText();
        String status = status_options;
	   
	   try {
	       // RETURN VALUE OBJECT DRIVER 
	   Class.forName(DRIVER);
	
	   // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	   // c is a object from Conecctor class
	   //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	   c = dm.getConnection(DB_URL, USER, PASS);
	
	   // buat objek statement
	   // s is a object from Conecctor class
	   //dm is object from Conecctor class that run the function(createStatement) 
	   s = c.createStatement();
	   
	   r = s.executeQuery("SELECT * FROM admin WHERE id_admin='"+Kode+"'");    	           
	   if (r.next()) { 
		   //Count Characters of The variable
		   int id_lenght = id.length(); 
           int username_lenght = username.length();
           int password_lenght = password.length(); 
           int alamat_lenght = alamat.length(); 
           int kontak_lenght = kontak.length();
           int status_lenght = status.length(); 
           
		   // define the text field
		   if (id_lenght == 0) {  
			   text ="ID ADMIN TIDAK BOLEH KOSOSNG"; // set Main class variable
			   Main_class.login();// run method from Main class
		   }
			   else if (id_lenght > 50) {
				   text ="JUMLAH KARAKTER ID ADMIN MELEBIHI 50 KATA"; // set Main class variable
				   Main_class.login();// run method from Main class
			   }
			   else if (isNumeric(id) == false) {
				   text ="ID ADMIN TIDAK BOLEH MENGANDUNG ALFABET"; // set Main class variable
				   Main_class.login();	// run method from Main class
			   } 
               
               // define the text field
               else if (username_lenght == 0) {  
            	   text ="USERNAME TIDAK BOLEH KOSOSNG"; // set Main class variable
            	   Main_class.login();// run method from Main class
               }
               else if (username_lenght > 50) {
           			text ="JUMLAH KARAKTER USERNAME MELEBIHI 50 KATA"; // set Main class variable
           			Main_class.login();// run method from Main class
               }
               else if (isNumeric(username) == true) {
   					text ="USERNAME TIDAK BOLEH MENGANDUNG ANGKA"; // set Main class variable
   					Main_class.login();	// run method from Main class
               }
               
               // define the field
               else if (password_lenght == 0) {
               		text = "PASSWORD TIDAK BOLEH KOSOSNG"; // set Main class variable
               		Main_class.login();// run method from Main class
               }
               else if (password_lenght > 50) {
   					text ="JUMLAH KARAKTER PASSWORD MELEBIHI 50 KATA"; // set Main class variable
   					Main_class.login();// run method from Main class
               }
               
               // define the field
               else if (alamat_lenght == 0) {
               		text = "ALAMAT TIDAK BOLEH KOSOSNG"; // set Main class variable
               		Main_class.login();// run method from Main class
               }else if (alamat_lenght > 150) {
               		text ="JUMLAH KARAKTER ALAMAT MELEBIHI 150 KATA"; // set Main class variable
               		Main_class.login();// run method from Main class
               }
               
               
               // define the text field of no hp
               else if (kontak_lenght == 0) {
               		text ="TELEPON TIDAK BOLEH KOSONG"; // set Main class variable
               		Main_class.login();// run method from Main class
               }
               else if (kontak_lenght < 11) {
   					text = "TELEPON KURANG DARI 11 KARAKTER"; // set Main class variable
   					Main_class.login();// run method from Main class
               }
               else if (kontak_lenght > 13) {
               		text ="TELEPON LEBIH DARI 13 KARAKTER"; // set Main class variable
               		Main_class.login();// run method from Main class
               }
               else if (isNumeric(kontak) == false) {
               		text ="TELEPON HARUS MENGGUNAKAN ANGKA"; // set Main class variable
               		Main_class.login();	// run method from Main class
               }
               
               // define the text field 
               else if (status_lenght == 0) {
               		text ="STATUS TIDAK BOLEH KOSONG"; // set Main class variable
               		Main_class.login();// run method from Main class          	
               }
               else if (status_lenght > 50) {
               		text ="JUMLAH KARAKTER STATUS MELEBIHI 50 KATA"; // set Main class variable
               		Main_class.login();// run method from Main class
               }       	                   
	       else {
	           // convert method variable to uppercase
	    	   String username_uppercase = username.toUpperCase();
	    	   String alamat_uppercase = alamat.toUpperCase();
	    	   String kontak_uppercase = kontak.toUpperCase();
	    	   String status_uppercase = status.toUpperCase();
	           //
	           
	           // UPDATE
	    	   String insert ="UPDATE admin SET username ='"+username_uppercase+"',password ='"+password+"',alamat ='"+alamat_uppercase+"',no_hp ='"+kontak_uppercase+"',status ='"+status_uppercase+"' WHERE id_admin='"+Kode+"'";
	           s.executeUpdate(insert);
	           text = "DATA TELAH DI UPDATE";//set attribut text from main class
	           Main_class.login();// run method from Main class
	           show_data();// run method show data
	           clear_textfield();
	           Kode="";
	       }
	   }
	   else if (table.getSelectionModel().isSelected(table.getSelectionModel().getSelectedIndex())) {
		  text = "Tekan Tombol Show"; // set attribut text from main class
	 	  Main_class.login(); // run method from Main class   
	   }
	   else{
		  text = "Baris Table Belum Di Pilih"; // set attribut text from main class
		  Main_class.login(); // run method from Main class    
	       }       
	   } 
	   catch (Exception e) {
	       e.printStackTrace();
	   }
	 } // end of update
    
    // method to clear textfields
	public void clear_textfield() {
		id_field.setText("");
		username_field.setText("");
		password_field.setText("");
        alamat_field.setText("");
        kontak_field.setText("");
        search_field.setText("");
        id_field.setDisable(false);
	}
	
    // method to clear textfields
	public void show() {
		if (table.getSelectionModel().isSelected(table.getSelectionModel().getSelectedIndex())) {
			//Select Item From Table View
	    	Admin selected_item = table.getSelectionModel().getSelectedItem();
			
	    	// Set Value Of Forms In FXML File
			id_field.setText(selected_item.getId_output());
			username_field.setText(selected_item.getUsername_output());
	        alamat_field.setText(selected_item.getAlamat_output());
	        kontak_field.setText(selected_item.getNo_hp_output());
	    	Kode = selected_item.getId_output();
	    	id_field.setDisable(true);
	    	status_combobox2.setValue(selected_item.getStatus_output());
	    	status_options = selected_item.getStatus_output();
	    	
	    	try {
	    		Class.forName(DRIVER);
			 	c = dm.getConnection(DB_URL, USER, PASS);
			 	s = c.createStatement();	 	   
			 	r = s.executeQuery("SELECT * FROM admin WHERE id_admin='"+Kode+"'");
			 	r.next();
			 	password_field.setText(r.getString("password"));
			} catch (Exception e) {
				// TODO: handle exception
			}
	    	 
		}else {
			text = "Pilih Baris Table Terlebih Dahulu";
			Main_class.login();
		}		
	}
	
	// method to search data
	public void search_data() {
		ObservableList<Admin> search_data = FXCollections.observableArrayList();
		try {
            // RETURN VALUE OBJECT DRIVER 
            Class.forName(DRIVER);

            // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
            // c is a object from Conecctor class
            //dm is object from Conecctor class that run the function(getConnection) and set the parameters
            c = dm.getConnection(DB_URL, USER, PASS);

            // buat objek statement
            // s is a object from Conecctor class
            //dm is object from Conecctor class that run the function(createStatement) 
            s = c.createStatement();
            
            String get_search_field = search_field.getText();
            
            r = s.executeQuery("SELECT * FROM admin WHERE username='"+get_search_field+"'");           
            while (r.next()) {
	        	// get data from database and set constructor of Admin class
            	Admin admin_object = new Admin(r.getString("id_admin"),r.getString("username"),"********",r.getString("alamat"),r.getString("no_hp"),r.getString("status"));
            	search_data.add(admin_object);// set data object to get data from admin object                 
            }
            			
			table.setItems(search_data); // set data of ObservableList<Admin> to the table 
			Id_col.setCellValueFactory(new PropertyValueFactory<Admin, String>("Id_output"));// display value to the column 
			username_col.setCellValueFactory(new PropertyValueFactory<Admin, String>("Username_output"));// display value to the column 
			password_col.setCellValueFactory(new PropertyValueFactory<Admin, String>("Password_output"));// display value to the column 
			alamat_col.setCellValueFactory(new PropertyValueFactory<Admin, String>("Alamat_output"));// display value to the column 
			no_col.setCellValueFactory(new PropertyValueFactory<Admin, String>("No_hp_output"));// display value to the column 
			Status_col.setCellValueFactory(new PropertyValueFactory<Admin, String>("Status_output"));// display value to the column					
		} catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	// method to create pdf
		public void Create_pdf() {
//			 try {                      
//		            // RETURN VALUE OBJECT DRIVER 
//		            Class.forName(DRIVER);
//
//		            // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
//		            // c is a object from Conecctor class
//		            //dm is object from Conecctor class that run the function(getConnection) and set the parameters
//		            c = dm.getConnection(DB_URL, USER, PASS);
//
//		            // buat objek statement
//		            // s is a object from Conecctor class
//		            //dm is object from Conecctor class that run the function(createStatement) 
//		            s = c.createStatement();
//		           
//		            //String search_pdf = search.getText();// get String 
//		            
//		            // set location 
//		            r = s.executeQuery("SELECT * FROM admin");
//		            
//		            // Initialize PDF document
//		            PdfDocument pdf = new PdfDocument(new PdfWriter(location));                  
//		           
//		            // Creating a Document object       
//		            Document doc = new Document(pdf);
//		            
//		          //CREATING AN IMAGETAE OBJECT
//	    			String imFile = "C:\\Users\\Fajar\\eclipse-workspace\\Skripsi\\src\\images\\Logo.png";
//	    			ImageData data = ImageDataFactory.create(imFile);
//	    		//
//	    
//	    		// CREATING AN IMAGE OBJECT
//	    			Image image = new Image(data).setHeight(50).setWidth(50).setFixedPosition(270, 765);
//	    		//
//		            
//		             // Creating a table 
//		            float [] pointColumnWidths = {100F, 100F, 150F, 150F};  
//		            Table table = new Table(pointColumnWidths);
//		            table.setRelativePosition(0, 150, 0, 0);
//		            
//		            //add font object
//		            PdfFont bold = PdfFontFactory.createFont(StandardFonts.TIMES_BOLD);
//		            
//		         // adding cells to the table
//	        		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("KODE").setBold().setFontColor(ColorConstants.WHITE)));
//	        		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("NAMA").setBold().setFontColor(ColorConstants.WHITE))); 
//	        		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("ALAMAT").setBold().setFontColor(ColorConstants.WHITE))); 
//	        		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("KOTA").setBold().setFontColor(ColorConstants.WHITE))); 
//	        		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("PROVINSI").setBold().setFontColor(ColorConstants.WHITE))); 
//	        		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("TELEPON").setBold().setFontColor(ColorConstants.WHITE))); 
//	        	//
//		            
//		            while (r.next()) {
//		            
//		            // DEFINE LOCAL VARIABLE 
//		            String kode_pdf = r.getString("KODE");
//	                String nama_pdf = r.getString("NAMA");
//		            String alamat_pdf = r.getString("ALAMAT");
//		            String kota_pdf = r.getString("KOTA");
//		            String provinsi_pdf = r.getString("PROVINSI");
//		            String telepon_pdf = r.getString("TELEPON");
//		            
//		            // Adding cells to the table
//		            table.addCell(new Cell().add(new Paragraph(kode_pdf)));
//		            table.addCell(new Cell().add(new Paragraph(nama_pdf))); 
//		            table.addCell(new Cell().add(new Paragraph(alamat_pdf))); 
//		            table.addCell(new Cell().add(new Paragraph(kota_pdf)));
//		            table.addCell(new Cell().add(new Paragraph(provinsi_pdf))); 
//		            table.addCell(new Cell().add(new Paragraph(telepon_pdf)));
//		            }
//		            
//		         // HEADER
//		            Text title2 = new Text("TB CHANDRA")
//		            	.setFont(PdfFontFactory.createFont(StandardFonts.HELVETICA))
//		        		.setFontSize(12).setBold();
////		            Text title3 = new Text("Jl. Kemang, Sukatani, Kec. Tapos, Kota Depok, Jawa Barat 16454 \n TEL: 0852-0113-3716, PEMILIK : Ali Zainal Abidin")
////		            	.setFont(PdfFontFactory.createFont(StandardFonts.HELVETICA))
////		            	.setFontSize(9);
//		            Paragraph header = new Paragraph(title2);
//		            //Paragraph header2 = new Paragraph(title3);
//		        //
//	            
//	            // set the text to the document
//	        		Text line = new Text("============================================================================");
//	        		Text title4 = new Text("DATA SUPLIER").setBold().setFontSize(12);  
//	        		Paragraph Line = new Paragraph(line);
//	        		Paragraph paragraph = new Paragraph(title4);
//	        		
//	        		LocalDate pdfdate = LocalDate.now();
//	        		String format = pdfdate.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG));
//	        		String name = "";
//	        	
//	        		//Paragraph currenttime2 = new Paragraph("Jakarta, "+format + " \n  PEMILIK \n \n \n \n \n Ali Zainal Abidin").setRelativePosition(200, 180, 0, 0);
//	        		//currenttime2.setTextAlignment(TextAlignment.CENTER);
//	        	//
//	        		doc.add(image);
//	        		doc.add(table);
//	        		//doc.add(currenttime2);
//	        		
//	            for (int i = 1; i <= pdf.getNumberOfPages(); i++) { // LOOP FOOTER FOR EACH PAGE
//					Rectangle dd = pdf.getPage(i).getPageSize(); // GET PAGE NUMBER 
//					
//					float x = dd.getWidth() / 2;
//					float y = dd.getTop() - 100;
//					
//					float x2 = dd.getWidth() / 2;
//					float y2 = dd.getTop() - 125;
//					
//					float x3 = dd.getWidth() / 2;
//					float y3 = dd.getTop() - 145;
//					
//					float x4 = dd.getWidth() / 2;
//					float y4 = dd.getTop() - 165;
//					
//					float x5 = dd.getWidth() / 2;
//					float y5 = dd.getTop() - 185;
//								
//					doc.showTextAligned(header,x, y, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
//					//doc.showTextAligned(header2,x2, y2, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);        
//					doc.showTextAligned(Line,x3,y3, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
//					doc.showTextAligned(paragraph,x4, y4, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
//					doc.showTextAligned(Line,x5,y5, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);								
//				}
//	            //	            
//		            // notif
//		            text =" Pdf Telah Dibuat";	// set Main class variable
//		            Main_class.login(); 	// run Main class method
//		            doc.close();	// close document         
//		        } catch (Exception e) {
//		            e.printStackTrace();
//		        }
			}
		// method to create pdf
		
}
