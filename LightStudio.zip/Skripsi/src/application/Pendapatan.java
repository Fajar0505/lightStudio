package application;

public class Pendapatan {
    // class variable
		private String DATE,MODAL,OMSET,GAJI,PROFIT;
	//
	
	public Pendapatan (String date, String modal, String omset, String gaji, String profit) {
		this.DATE = date;
		this.MODAL = modal;
		this.OMSET = omset;
		this.GAJI = gaji;
		this.PROFIT = profit;
	}
	public String getDate() {
		return DATE;
	}
	public String getModal() {
		return MODAL;
	}
	public String getOmset() {
		return OMSET;
	}
	public String getGaji() {
		return GAJI;
	}
	public String getProfit() {
		return PROFIT;
	}
}
