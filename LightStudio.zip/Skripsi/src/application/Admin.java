package application;

public class Admin {
    // class variable
	private String id_output;
	private String username_output ;
	private String password_output;
	private String alamat_output;
	private String no_hp_output;
	private String status_output;
	//
	
	public Admin (String id_output, String username_output, String password_output, String alamat_output, String no_hp_output, String status_output ) {
		this.id_output = id_output;
		this.username_output = username_output;
		this.password_output = password_output;
		this.alamat_output = alamat_output;
		this.no_hp_output = no_hp_output;
		this.status_output = status_output;
	}
	
	
	public String getId_output() {
		return id_output;
	}
	
	
	public String getUsername_output() {
		return username_output;
	}
	
	
	public String getPassword_output() {
		return password_output;
	}
	
	
	public String getAlamat_output() {
		return alamat_output;
	}
	
	
	public String getNo_hp_output() {
		return no_hp_output;
	}
	
	
	public String getStatus_output() {
		return status_output;
	}
}

