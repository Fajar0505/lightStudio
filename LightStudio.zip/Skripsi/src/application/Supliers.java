package application;

public class Supliers {
    // class variable
		private String KODE,NAMA,ALAMAT,KOTA,PROVINSI,TELEPON;
	//
	
	public Supliers (String kode, String nama, String alamat, String kota, String provinsi, String telepon ) {
		this.KODE = kode;
		this.NAMA = nama;
		this.ALAMAT = alamat;
		this.KOTA = kota;
		this.PROVINSI = provinsi;
		this.TELEPON = telepon;
	}

	public String getKode() {
		return KODE;
	}
	public String getNama() {
		return NAMA;
	}
	public String getAlamat() {
		return ALAMAT;
	}
	public String getKota() {
		return KOTA;
	}
	public String getProvinsi() {
		return PROVINSI;
	}

	public String getTelepon() {
		return TELEPON;
	}


}
