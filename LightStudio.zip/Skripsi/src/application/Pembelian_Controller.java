package application;

//IMPORT ATTRIBUTES FROM MY OWN CLASS
import static application.Koneksi.*;
import static application.Main.*;
import static application.Login_Controller.*;

import java.net.URL;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;
import java.util.ResourceBundle;

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.VerticalAlignment;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class Pembelian_Controller implements Initializable {
	// location to save pdf file
	static final String location = "C:\\Users\\Fajar\\Documents\\Light Studio\\Report\\pembelian.pdf";
	// Create Object for Main Class
	Main Main_class = new Main(); 
	// Class Variable
	static String get_jumlah_barang,Kode,verify_nama_barang,get_jenis_barang;
	static String status_options="";
	static String kelamin_options="";
	static int new_stock;

	//  FXML CODES AREA
	@FXML
	private Label username,status;
	@FXML
	private Button pembelian_btn,barang_btn,penjualan_btn,gaji_karyawan_btn,pendapatan_btn,update_btn,show_btn,
	suplier_btn,karyawan_btn,admin_btn,keluar_btn,search_btn,pdf_button,input_btn,hapus_btn,delete_btn;
	@FXML
	private TableView<Pembelian> table;
	@FXML
	private TableColumn<Pembelian, String> id_pembelian_col,nama_barang_col,jenis_barang_col,jumlah_barang_col,harga_total_col,tanggal_pembelian_col,keterangan_col;
	@FXML
	private TextField nama_barang_field,jenis_barang_field,jumlah_barang_field,total_harga_field,keterangan_field,search_field;
	@FXML
	private DatePicker tanggal_pembelian;
	
	// Over Write Method 
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		tanggal_pembelian.setValue(LocalDate.now());
	}
	
	//Methos For Buttons of FXML File
	public void Button_Action(ActionEvent event) {
		if (event.getSource() == penjualan_btn) {
			Direktur_Controller Direktur_Controller_Object = fxml_file2.getController(); // Object Controller Class		
			// Run Method From Other Controllers
			Direktur_Controller_Object.show_name();
			Direktur_Controller_Object.show_data();			
			window.setScene(layer_in_stage2); //Move to Penjualan Page
		}else if (event.getSource() == barang_btn) {
			Barang_Controller Barang_Controller_Object = fxml_file10.getController();	
			Barang_Controller_Object.show_name();// Run Method From Other Controllers
			Barang_Controller_Object.show_data();
			window.setScene(layer_in_stage10); //Move to Barang Page
		}else if (event.getSource() == pembelian_btn) {
			Pembelian_Controller Pembelian_Controller_Object = fxml_file9.getController();	
			Pembelian_Controller_Object.show_name();// Run Method From Other Controllers
			Pembelian_Controller_Object.show_data();
			window.setScene(layer_in_stage9); //Move to Pembelian Page
		}else if (event.getSource() == gaji_karyawan_btn) {
			Gaji_Controller Gaji_Controller_Object = fxml_file8.getController();	
			Gaji_Controller_Object.show_name();// Run Method From Other Controllers
			Gaji_Controller_Object.show_data();
			window.setScene(layer_in_stage8); //Move to Gaji Page
		}else if (event.getSource() == pendapatan_btn) {
			Pendapatan_Controller Pendapatan_Controller_Object = fxml_file12.getController();
			Pendapatan_Controller_Object.MODAL(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.PENGELUARAN_GAJI(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.OMSET(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.MOENY(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.show_data(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.show_name(); // RUN METHOD FROM OTHER CONTROLLER
			window.setScene(layer_in_stage12); //Move to Pendapatan Page
		}else if (event.getSource() == suplier_btn) {
			// Object Controller Class
			Suplier_Controller Suplier_Controller_Object = fxml_file5.getController();	
			Suplier_Controller_Object.show_name();// Run Method From Other Controllers
			Suplier_Controller_Object.show_data();	
			window.setScene(layer_in_stage5); //Move to Suplier Page
		}else if (event.getSource() == karyawan_btn) {
			// Object Controller Class
			Karyawan_Controller Karyawan_Controller_Object = fxml_file6.getController();	
			Karyawan_Controller_Object.show_name();// Run Method From Other Controllers
			Karyawan_Controller_Object.show_data();// Run Method From Other Controllers
			window.setScene(layer_in_stage6); //Move to Karyawan Page			
		}else if (event.getSource() == admin_btn) {
			// Object Controller Class
			Admin_Controller Admin_Controller_Object = fxml_file7.getController();	
			Admin_Controller_Object.show_name();// Run Method From Other Controllers
			Admin_Controller_Object.show_data();// Run Method From Other Controllers
			window.setScene(layer_in_stage7); //Move to Admin Page
		}else if (event.getSource() == keluar_btn) {
			window.setX(350);
			window.setY(170);
			window.setScene(layer_in_stage);
			login_username =""; 
		}
		else if (event.getSource() == search_btn) {
			search_data();
		}
		else if (event.getSource() == pdf_button) {
			Create_pdf(); 
		}
		else if (event.getSource() == input_btn) {
			input_data();  
		}
		else if (event.getSource() == hapus_btn) {
			clear_textfield(); // run method
		}
		else if (event.getSource() == delete_btn) {
			delete(); // run method
		}else if (event.getSource() == update_btn) {
			update(); // run method
		}else if (event.getSource() == show_btn) {
			show(); // run method
		}
	}
				
	//method to show admin's name
	public void show_name() { 
		username.setText(login_username);
		status.setText(index);
	}
	
	//  Method To Visible FXML Components
	public void BUTTONS_VISIBLE() {
        if (index.equals("KARYAWAN")) {
        	// set visible for menu buttons
        	gaji_karyawan_btn.setVisible(false);
        	pendapatan_btn.setVisible(false);
        	suplier_btn.setVisible(false);
        	karyawan_btn.setVisible(false);
        	admin_btn.setVisible(false);	        	
		}else if (index.equals("DIREKTUR")) {
			// set visible for menu buttons
        	gaji_karyawan_btn.setVisible(true);
        	pendapatan_btn.setVisible(true);
        	suplier_btn.setVisible(true);
        	karyawan_btn.setVisible(true);
        	admin_btn.setVisible(true);	
		}
	}
	
	// method for table view
	public ObservableList<Pembelian> list_data(){ // non void method, to get data from database and set to observableArrayList()
		ObservableList<Pembelian> data =FXCollections.observableArrayList();// container for the data
		try {
	        // RETURN VALUE OBJECT DRIVER 
	        Class.forName(DRIVER);
	
	        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	        // c is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	        c = dm.getConnection(DB_URL, USER, PASS);
	
	        // buat objek statement
	        // s is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(createStatement) 
	        s = c.createStatement();
	        
	        // difine Resultset as statment to exucute query to suppliers table
	        // r is Resultset object
	        r = s.executeQuery("SELECT * FROM pembelian");
	        	        
	        while (r.next()) {
	        	Double currency = new Double(r.getInt("harga_total")); 
        		String currencyOut;
        		
	        	NumberFormat currencyFormatter; // OBJECT OF NUMBERFORMAT CLASS 				            
	            Locale s = new Locale("id", "ID");// OBJECT OF LOCALE		            
	            currencyFormatter = NumberFormat.getCurrencyInstance(s); // RUN METHOD 		            
	            currencyOut = currencyFormatter.format(currency); // RUN METHOD
	            
	        	// get data from database and set constructor of suppliers class
	        	Pembelian pembelian_object = new Pembelian(r.getString("id_pembelian"),r.getString("nama_barang"),r.getString("jenis_barang"),r.getString("jumlah_barang")
	        											   ,currencyOut,r.getString("tgl_pembelian"),r.getString("keterangan"));
	        	data.add(pembelian_object);// set data object to get data from admin object 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data; // return ObservableListvalue			
	} 
	
	// method to show data to the table
	public void show_data(){
		try {
			ObservableList<Pembelian> list = list_data(); // create ObservableList object and run list_data method 
			table.setItems(list); // set data of ObservableList<Karyawan> to the table
			id_pembelian_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Id_Pembelian"));// display value to the column 
			nama_barang_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Nama_Barang"));// display value to the column 
			jenis_barang_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Jenis_Barang"));// display value to the column 
			jumlah_barang_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Jumlah_Barang"));// display value to the column
			harga_total_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Harga_Total"));// display value to the column 
			tanggal_pembelian_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Tgl_Pembelian"));// display value to the column 
			keterangan_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Keterangan"));// display value to the column 	
		} 	
		catch (Exception e) {				
			System.out.print("show data is error");
			e.printStackTrace();
		}
	}	// method to show data to the table
	
	// Delete Method
	public void delete() {
		if (table.getSelectionModel().isSelected(table.getSelectionModel().getSelectedIndex())) {
			Pembelian selected_item = table.getSelectionModel().getSelectedItem();
		      try {
		      // RETURN VALUE OBJECT DRIVER 
		      Class.forName(DRIVER);
		
		      // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
		      // c is a object from Conecctor class
		      //dm is object from Conecctor class that run the function(getConnection) and set the parameters
		      c = dm.getConnection(DB_URL, USER, PASS);
		
		      // buat objek statement
		      // s is a object from Conecctor class
		      //dm is object from Conecctor class that run the function(createStatement) 
		      s = c.createStatement();
		      r = s.executeQuery("SELECT * FROM pembelian WHERE id_pembelian='"+selected_item.getId_Pembelian()+"'");
		      if (r.next()) {
		    	  verify_nama_barang = r.getString("nama_barang"); // get data
		    	  new_stock = Integer.parseInt(r.getString("jumlah_barang"));
		          
		    	  s.executeUpdate("DELETE FROM pembelian WHERE id_pembelian='"+selected_item.getId_Pembelian()+"'");
		          update_stock_barang();
		    	  
		          text = selected_item.getId_Pembelian()+" HAS DELETED"; // set Main class variable
		          Main_class.login(); // run method from Main class
		          clear_textfield(); // run method
		          show_data(); // run method
		      }
		      else{
		      	text = "THE ID WAS NOT FOUND"; // set Main class variable
		      	Main_class.login(); // run method from Main class 
		          clear_textfield(); // run method
		      }
		  }
		  catch (Exception e) {
		      e.printStackTrace();
		  }
		}
		else {
			text ="Baris Table Belum Di Pilih";
			Main_class.login();
		}
	}
	
	public void update_stock_barang() throws Exception {
		Class.forName(DRIVER);
		c = dm.getConnection(DB_URL, USER, PASS);
		s = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		r = s.executeQuery("SELECT * FROM barang WHERE nama_barang='"+verify_nama_barang+"'"); 
		if (r.next()) {
			int jumlah_barang_sebelumnya = Integer.parseInt(r.getString("jumlah_barang"));
			int jumlah_barang_terbaru = jumlah_barang_sebelumnya - new_stock;
			
			String sql_code ="UPDATE barang SET jumlah_barang ='"+jumlah_barang_terbaru+"' WHERE nama_barang='"+verify_nama_barang+"'";
            s.executeUpdate(sql_code);
		}
	}
	
	// method to check a variable is numeric or not
	public static boolean isNumeric(String str) { 
        return str != null && str.matches("[-+]?\\d*\\.?\\d+");
    }
		
	// method to input data to the database
    public void input_data() { 	   	
    	// method variable
        String nama_barang = nama_barang_field.getText();
        String jenis_barang = jenis_barang_field.getText();
        String jumlah_barang = jumlah_barang_field.getText();
        String total_harga = total_harga_field.getText();
        String keterangan = keterangan_field.getText();
        LocalDate tanggal_storage = tanggal_pembelian.getValue();
	                
        try {          
        	//Count Characters of The variable
            int nama_barang_lenght = nama_barang.length(); 
            int jenis_barang_lenght = jenis_barang.length();
            int jumlah_barang_lenght = jumlah_barang.length(); 
            int total_harga_lenght = total_harga.length();
            int keterangan_lenght = keterangan.length(); 
            
            // define the text field
            if (nama_barang_lenght == 0) {  
            	text ="NAMA BARANG TIDAK BOLEH KOSONG"; // set Main class variable
            	Main_class.login();// run method from Main class
        	}
	            else if (nama_barang_lenght > 100) {
	        		text ="JUMLAH KARAKTER NAMA BARANG MELEBIHI 100 KATA"; // set Main class variable
	        		Main_class.login();// run method from Main class
				}  
	            
	            // define the field
	            else if (jenis_barang_lenght == 0) {
	            	text = "JENIS BARANG TIDAK BOLEH KOSONG"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}else if (jenis_barang_lenght > 100) {
	            	text ="JUMLAH KARAKTER JENIS BARANG MELEBIHI 100 KATA"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}
            
            	// define the field
	            else if (jumlah_barang_lenght == 0) {
	            	text = "JUMLAH BARANG TIDAK BOLEH KOSONG"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}else if (jumlah_barang_lenght > 100) {
	            	text ="JUMLAH KARAKTER JUMLAH BARANG MELEBIHI 100 KATA"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}else if (isNumeric(jumlah_barang) == false) {
					text ="JUMLAH BARANG TIDAK BOLEH MENGANDUNG ALFABET"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}
            
            	// define the field
	            else if (total_harga_lenght == 0) {
	            	text = "TOTAL HARGA TIDAK BOLEH KOSONG"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}else if (total_harga_lenght > 100) {
	            	text ="JUMLAH KARAKTER TOTALH HARGA MELEBIHI 100 KATA"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}else if (isNumeric(total_harga) == false) {
					text ="TOTAL HARGA TIDAK BOLEH MENGANDUNG ALFABET"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}
            
            	// define the field
	            else if (keterangan_lenght == 0) {
	            	text = "KETERANGAN TIDAK BOLEH KOSONG"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}else if (keterangan_lenght > 100) {
	            	text ="JUMLAH KARAKTER KETERANGAN MELEBIHI 100 KATA"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}
                      	              	                            
            else {
            	// MYsql code
            	Class.forName(DRIVER);
     	        c = dm.getConnection(DB_URL, USER, PASS);
     	        s = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
     	        r = s.executeQuery("SELECT * FROM pembelian");    
     	        r.last();
     	        
     	        // Condition when there's no any data in pembelian 
     	        if (r.getRow() == 0) {
     	        	// Local variable
     	        	String first_code = "P1";

     	        	//convert method variable to uppercase
     	        	String nama_barang_uppercase = nama_barang.toUpperCase();
     	        	String jenis_barang_uppercase = jenis_barang.toUpperCase();
     	        	String keterangan_uppercase = keterangan.toUpperCase();
                    
     	        	// Update
                    String insert ="INSERT INTO pembelian VALUES"+"('"+first_code+"',"+"'"+nama_barang_uppercase+"',"+"'"+jenis_barang_uppercase+"',"+"'"+jumlah_barang+"',"+"'"+total_harga+"',"+"'"+tanggal_storage+"',"+"'"+keterangan_uppercase+"')";
                    s.execute(insert);
                    
                    // Static Variable
                    verify_nama_barang = nama_barang_uppercase;
                    get_jumlah_barang = jumlah_barang;
                    get_jenis_barang = jenis_barang_uppercase;
                    input_barang(); // Input Data To Barang
                    
                    text = "DATA TELAH DI INPUT";	// set Main class variable
                    Main_class.login();				// run method from Main class
                    show_data(); 					// run method                    
                    clear_textfield();       	        
				} 
     	        
     	        // Condition when pembelian already has data
     	        else {			
                	int kode = r.getRow();
                	String get_kode = r.getString("id_pembelian");
                	String remove_code = get_kode.replace("P","");
                	int remove_code_to_string = Integer.parseInt(remove_code);  
                	int kode2 = 1 + remove_code_to_string;
                	String final_code = "P"+String.valueOf(kode2);
                	
                	//convert method variable to uppercase
     	        	String nama_barang_uppercase = nama_barang.toUpperCase();
     	        	String jenis_barang_uppercase = jenis_barang.toUpperCase();
     	        	String keterangan_uppercase = keterangan.toUpperCase();
                      
                    String insert ="INSERT INTO pembelian VALUES"+"('"+final_code+"',"+"'"+nama_barang_uppercase+"',"+"'"+jenis_barang_uppercase+"',"+"'"+jumlah_barang+"',"+"'"+total_harga+"',"+"'"+tanggal_storage+"',"+"'"+keterangan_uppercase+"')";
                    s.execute(insert);
                    
                    verify_nama_barang = nama_barang_uppercase;
                    get_jumlah_barang = jumlah_barang;
                    get_jenis_barang = jenis_barang_uppercase;
                    input_barang();
                    
                    text = "DATA TELAH DI INPUT";	// set Main class variable
                    Main_class.login();				// run method from Main class
                    show_data(); 					// run method                    
                    clear_textfield();
				}             	
            } // else       
        } //try 
		catch (Exception e) {
		    e.printStackTrace();
		}
    } // end of method to input data to the database
    
    
	// input Barang
	public void input_barang() {
		try {
			Class.forName(DRIVER);
			c = dm.getConnection(DB_URL, USER, PASS);
			s = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			r = s.executeQuery("SELECT * FROM barang WHERE nama_barang='"+verify_nama_barang+"'"); 
			
			if (r.next()) {
				
				String jumlah_barang_sekarang = r.getString("jumlah_barang"); // Get data from database
				
				//convert sting to int
				int jumlah_sekarang = Integer.parseInt(jumlah_barang_sekarang);
				int jumlah_tambahan = Integer.parseInt(get_jumlah_barang);
				int jumlah_barang_terbaru =  jumlah_sekarang + jumlah_tambahan;
				
				String insert ="UPDATE barang SET jumlah_barang ='"+jumlah_barang_terbaru+"' WHERE nama_barang='"+verify_nama_barang+"'";
                s.executeUpdate(insert);
				
			} else {
				String harga_jual = "0"; // local variable
				r = s.executeQuery("SELECT * FROM barang");
				r.last();
				if (r.getRow() == 0) {
					String first_code = "B1"; // Local Variable
					
					// input Data
					String insert ="INSERT INTO barang VALUES"+"('"+first_code+"',"+"'"+verify_nama_barang+"',"+"'"+get_jenis_barang+"',"+"'"+get_jumlah_barang+"',"+"'"+harga_jual+"')";
                    s.execute(insert);	
				}
				else {
					// generate code or id
					int kode = r.getRow();
	            	String get_kode = r.getString("id_barang");
	            	String remove_code = get_kode.replace("B","");
	            	int remove_code_to_string = Integer.parseInt(remove_code);  
	            	int kode2 = 1 + remove_code_to_string;
	            	String final_code = "B"+String.valueOf(kode2);
	                  
	            	String insert ="INSERT INTO barang VALUES"+"('"+final_code+"',"+"'"+verify_nama_barang+"',"+"'"+get_jenis_barang+"',"+"'"+get_jumlah_barang+"',"+"'"+harga_jual+"')";
	                s.execute(insert);
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
     
    // Update Method
    public void update() {  		        	
    	// method variable  	
    	 String nama_barang = nama_barang_field.getText();
         String jenis_barang = jenis_barang_field.getText();
         String jumlah_barang = jumlah_barang_field.getText();
         String total_harga = total_harga_field.getText();
         String keterangan = keterangan_field.getText();
         LocalDate tanggal_storage = tanggal_pembelian.getValue();
       
       try {
           // RETURN VALUE OBJECT DRIVER 
           Class.forName(DRIVER);

           // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
           // c is a object from Conecctor class
           //dm is object from Conecctor class that run the function(getConnection) and set the parameters
           c = dm.getConnection(DB_URL, USER, PASS);

           // buat objek statement
           // s is a object from Conecctor class
           //dm is object from Conecctor class that run the function(createStatement) 
           s = c.createStatement();
           
           r = s.executeQuery("SELECT * FROM pembelian WHERE id_pembelian='"+Kode+"'");    	           
           if (r.next()) { 
        	   //Count Characters of The variable
        	   int nama_barang_lenght = nama_barang.length(); 
               int jenis_barang_lenght = jenis_barang.length();
               int jumlah_barang_lenght = jumlah_barang.length(); 
               int total_harga_lenght = total_harga.length();
               int keterangan_lenght = keterangan.length(); 

               // define the text field
               if (nama_barang_lenght == 0) {  
	               	text ="NAMA BARANG TIDAK BOLEH KOSONG"; // set Main class variable
	               	Main_class.login();// run method from Main class
           	   }
					else if (nama_barang_lenght > 100) {
						text ="JUMLAH KARAKTER NAMA BARANG MELEBIHI 100 KATA"; // set Main class variable
						Main_class.login();// run method from Main class
					}  
					
					// define the field
					else if (jenis_barang_lenght == 0) {
						text = "JENIS BARANG TIDAK BOLEH KOSONG"; // set Main class variable
						Main_class.login();// run method from Main class
					}else if (jenis_barang_lenght > 100) {
						text ="JUMLAH KARAKTER JENIS BARANG MELEBIHI 100 KATA"; // set Main class variable
						Main_class.login();// run method from Main class
						}
					   
					   	// define the field
					else if (jumlah_barang_lenght == 0) {
						text = "JUMLAH BARANG TIDAK BOLEH KOSONG"; // set Main class variable
						Main_class.login();// run method from Main class
					}else if (jumlah_barang_lenght > 100) {
						text ="JUMLAH KARAKTER JUMLAH BARANG MELEBIHI 100 KATA"; // set Main class variable
						Main_class.login();// run method from Main class
					}else if (isNumeric(jumlah_barang) == false) {
						text ="JUMLAH BARANG TIDAK BOLEH MENGANDUNG ALFABET"; // set Main class variable
		            	Main_class.login();// run method from Main class
					}
	            
					   
					   	// define the field
					else if (total_harga_lenght == 0) {
						text = "TOTAL HARGA TIDAK BOLEH KOSONG"; // set Main class variable
						Main_class.login();// run method from Main class
					}else if (total_harga_lenght > 100) {
						text ="JUMLAH KARAKTER TOTALH HARGA MELEBIHI 100 KATA"; // set Main class variable
						Main_class.login();// run method from Main class
					}else if (isNumeric(total_harga) == false) {
						text ="TOTAL HARGA TIDAK BOLEH MENGANDUNG ALFABET"; // set Main class variable
						Main_class.login();// run method from Main class
						}
					   
					   	// define the field
					else if (keterangan_lenght == 0) {
						text = "KETERANGAN TIDAK BOLEH KOSONG"; // set Main class variable
						Main_class.login();// run method from Main class
					}else if (keterangan_lenght > 100) {
						text ="JUMLAH KARAKTER KETERANGAN MELEBIHI 100 KATA"; // set Main class variable
						Main_class.login();// run method from Main class
					} 
               	                   
               else {
                   // convert method variable to uppercase
            	   	String nama_barang_uppercase = nama_barang.toUpperCase();
					String jenis_barang_uppercase = jenis_barang.toUpperCase();
					String keterangan_uppercase = keterangan.toUpperCase();
					
                   int old_stock = Integer.parseInt(r.getString("jumlah_barang"));
                   new_stock = Integer.parseInt(jumlah_barang) - old_stock;
                   verify_nama_barang = nama_barang_uppercase;
	                   
                   // UPDATE
                   String insert ="UPDATE pembelian SET nama_barang ='"+nama_barang_uppercase+"',jenis_barang ='"+jenis_barang_uppercase+"',jumlah_barang ='"+jumlah_barang+"',harga_total ='"+total_harga+"',tgl_pembelian ='"+tanggal_storage+"',keterangan ='"+keterangan_uppercase+"' WHERE id_pembelian='"+Kode+"'";
                   s.execute(insert);
                   update_barang(); 
                   
                   Kode="";
                   text = "DATA TELAH DI UPDATE";//set attribut text from main class
                   Main_class.login();// run method from Main class
                   show_data();// run method show data
                   clear_textfield();
                        
               }
           }
           else if (table.getSelectionModel().isSelected(table.getSelectionModel().getSelectedIndex())) {
        	  text = "Tekan Tombol Show"; // set attribut text from main class
         	  Main_class.login(); // run method from Main class   
           }
           else{
        	  text = "Baris Table Belum Di Pilih"; // set attribut text from main class
        	  Main_class.login(); // run method from Main class    
           }       
       } 
       catch (Exception e) {
           e.printStackTrace();
       }
	 } // end of update
    
 // Update Barang
 	public void update_barang() {
 		try {
 			Class.forName(DRIVER);
 			c = dm.getConnection(DB_URL, USER, PASS);
 			s = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
 			r = s.executeQuery("SELECT * FROM barang WHERE nama_barang='"+verify_nama_barang+"'"); 
 			
 			if (r.next()) {
 				int jumlah_barang_sekarang = Integer.parseInt(r.getString("jumlah_barang")); // Get data from database
 				int jumlah_barang_terbaru =  jumlah_barang_sekarang + new_stock;
 				
 				String insert ="UPDATE barang SET jumlah_barang ='"+jumlah_barang_terbaru+"' WHERE nama_barang='"+verify_nama_barang+"'";
                 s.executeUpdate(insert);
 			} 
 		} catch (Exception e) {
 			e.printStackTrace();
 		}		
 	}
 	
    // method to clear textfields
	public void clear_textfield() {
		nama_barang_field.setText("");
		jenis_barang_field.setText("");
		jumlah_barang_field.setText("");
		total_harga_field.setText("");
        search_field.setText("");
        keterangan_field.setText("");
	}
	
    // SHOW METHOD
	public void show() {
		if (table.getSelectionModel().isSelected(table.getSelectionModel().getSelectedIndex())) {
			try {
				//Select Item From Table View
		    	Pembelian selected_item = table.getSelectionModel().getSelectedItem();
		    	
				Kode =selected_item.getId_Pembelian(); // get id from selected row
				
				String get_tanggal  = selected_item.getTgl_Pembelian();
				LocalDate tanggal_update = LocalDate.parse(get_tanggal);
				
				Class.forName(DRIVER);
				c = dm.getConnection(DB_URL, USER, PASS);
				s = c.createStatement();
				r = s.executeQuery("SELECT * FROM pembelian WHERE id_pembelian='"+Kode+"'");
				r.next();
				
				nama_barang_field.setText(selected_item.getNama_Barang());
				jenis_barang_field.setText(selected_item.getJenis_Barang());
				jumlah_barang_field.setText(selected_item.getJumlah_Barang());
				total_harga_field.setText(r.getString("harga_total"));				
				tanggal_pembelian.setValue(tanggal_update);
				keterangan_field.setText(selected_item.getKeterangan());
				
			} catch (Exception e) {
				// TODO: handle exception
			}
		}else {
			text = "Pilih Baris Table Terlebih Dahulu";
			Main_class.login();
		}	
	}
	
	// method to search data
	public void search_data() {
		ObservableList<Pembelian> search_data = FXCollections.observableArrayList();
		try {
            // RETURN VALUE OBJECT DRIVER 
            Class.forName(DRIVER);

            // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
            // c is a object from Conecctor class
            //dm is object from Conecctor class that run the function(getConnection) and set the parameters
            c = dm.getConnection(DB_URL, USER, PASS);

            // buat objek statement
            // s is a object from Conecctor class
            //dm is object from Conecctor class that run the function(createStatement) 
            s = c.createStatement();
            
            String get_search_field = search_field.getText();
            
            r = s.executeQuery("SELECT * FROM pembelian WHERE tgl_pembelian='"+get_search_field+"'");           
            while (r.next()) {
	        	// get data from database and set constructor of Admin class
            	Pembelian pembelian_object = new Pembelian(r.getString("id_pembelian"),r.getString("nama_barang"),r.getString("nama_barang"),r.getString("jumlah_barang")
						   								   ,r.getString("harga_total"),r.getString("tgl_pembelian"),r.getString("keterangan"));
            	search_data.add(pembelian_object);// set data object to get data from admin object                 
            }
            			
			table.setItems(search_data); // set data of ObservableList<Admin> to the table 
			id_pembelian_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Id_Pembelian"));// display value to the column 
			nama_barang_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Nama_Barang"));// display value to the column 
			jenis_barang_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Jenis_Barang"));// display value to the column 
			jumlah_barang_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Jumlah_Barang"));// display value to the column
			harga_total_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Harga_Total"));// display value to the column 
			tanggal_pembelian_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Tgl_Pembelian"));// display value to the column 
			keterangan_col.setCellValueFactory(new PropertyValueFactory<Pembelian, String>("Keterangan"));// display value to the column			
		} catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	// method to create pdf
	public void Create_pdf() {
		 try {                      
	            // RETURN VALUE OBJECT DRIVER 
	            Class.forName(DRIVER);

	            // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	            // c is a object from Conecctor class
	            //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	            c = dm.getConnection(DB_URL, USER, PASS);

	            // buat objek statement
	            // s is a object from Conecctor class
	            //dm is object from Conecctor class that run the function(createStatement) 
	            s = c.createStatement();
	           
	            //String search_pdf = search.getText();// get String 
	            
	            // set location 
	            r = s.executeQuery("SELECT * FROM pembelian");
	            
	            // Initialize PDF document
	            PdfDocument pdf = new PdfDocument(new PdfWriter(location));                  
	           
	            // Creating a Document object       
	            Document doc = new Document(pdf);
	            
	          //CREATING AN IMAGETAE OBJECT
  			String imFile = "C:\\Users\\Fajar\\eclipse-workspace\\Skripsi\\src\\images\\logo.png";
  			ImageData data = ImageDataFactory.create(imFile);
  		//
  
  		// CREATING AN IMAGE OBJECT
  			Image image = new Image(data).setHeight(50).setWidth(50).setFixedPosition(270, 765);
  		//
	            
	             // Creating a table 
	            float [] pointColumnWidths = {0F,100F,100F,0F,100F,0F,0F};  
	            Table table = new Table(pointColumnWidths);
	            table.setRelativePosition(0, 150, 0, 0);
	            
	            //add font object
	            PdfFont bold = PdfFontFactory.createFont(StandardFonts.TIMES_BOLD);
	            
	         // adding cells to the table
      		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("ID").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("BARANG").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("JENIS").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("JUMLAH").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("HARGA TOTAL").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("TGL PEMBELIAN").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("KETERANGAN").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      		//table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("TELEPON").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
      	//
	            
	            while (r.next()) {
	            
	            // DEFINE LOCAL VARIABLE 
	            String A = r.getString("id_pembelian");
              String B = r.getString("nama_barang");
	            String C = r.getString("jenis_barang");
	            String D = r.getString("jumlah_barang");
	            String E = r.getString("harga_total");
	            String F = r.getString("tgl_pembelian");
	            String G = r.getString("keterangan");
	            
	            // Adding cells to the table
	            table.addCell(new Cell().add(new Paragraph(A).setFontSize(8)));
	            table.addCell(new Cell().add(new Paragraph(B).setFontSize(8))); 
	            table.addCell(new Cell().add(new Paragraph(C).setFontSize(8))); 
	            table.addCell(new Cell().add(new Paragraph(D).setFontSize(8)));
	            table.addCell(new Cell().add(new Paragraph(E).setFontSize(8))); 
	            table.addCell(new Cell().add(new Paragraph(F).setFontSize(8)));
	            table.addCell(new Cell().add(new Paragraph(G).setFontSize(8)));
	            }
	            
	         // HEADER
	            Text title2 = new Text("TB CHANDRA")
	            	.setFont(PdfFontFactory.createFont(StandardFonts.HELVETICA))
	        		.setFontSize(11).setBold();
	            Text title3 = new Text("Jl. Kemang, Sukatani, Kec. Tapos, Kota Depok, Jawa Barat 16454")
	            	.setFont(PdfFontFactory.createFont(StandardFonts.HELVETICA))
	            	.setFontSize(9);
	            Paragraph header = new Paragraph(title2);
	            Paragraph header2 = new Paragraph(title3);
	        //
          
          // set the text to the document
      		Text line = new Text("============================================================================");
      		Text title4 = new Text("LAPORAN PEMBELIAN").setBold().setFontSize(12);  
      		Paragraph Line = new Paragraph(line);
      		Paragraph paragraph = new Paragraph(title4);
      		
      		LocalDate pdfdate = LocalDate.now();
      		String name = "";
      		String ind_date = pdfdate.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL));
     		Paragraph currenttime2 = new Paragraph("Depok, "+ind_date + " \n  Direktur \n \n \n  (Chandra Kurniawan)").setRelativePosition(170, 180, 0, 0);
      		currenttime2.setTextAlignment(TextAlignment.CENTER);
      	//
      		doc.add(image);
      		doc.add(table);
      		doc.add(currenttime2);
      		
          for (int i = 1; i <= pdf.getNumberOfPages(); i++) { // LOOP FOOTER FOR EACH PAGE
				Rectangle dd = pdf.getPage(i).getPageSize(); // GET PAGE NUMBER 
				
				float x = dd.getWidth() / 2;
				float y = dd.getTop() - 100;
				
				float x2 = dd.getWidth() / 2;
				float y2 = dd.getTop() - 125;
				
				float x3 = dd.getWidth() / 2;
				float y3 = dd.getTop() - 145;
				
				float x4 = dd.getWidth() / 2;
				float y4 = dd.getTop() - 165;
				
				float x5 = dd.getWidth() / 2;
				float y5 = dd.getTop() - 185;
							
				doc.showTextAligned(header,x, y, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
				doc.showTextAligned(header2,x2, y2, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);        
				doc.showTextAligned(Line,x3,y3, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
				doc.showTextAligned(paragraph,x4, y4, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
				doc.showTextAligned(Line,x5,y5, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);								
			}
          //	            
	            // notif
	            text =" Pdf Telah Dibuat";	// set Main class variable
	            Main_class.login(); 	// run Main class method
	            doc.close();	// close document         
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		}
		// method to create pdf
		
}
