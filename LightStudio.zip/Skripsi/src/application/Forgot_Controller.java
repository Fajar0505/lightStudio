package application;

//Import my own class
import static application.Koneksi.*;
import static application.Main.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;

public class Forgot_Controller {
	static String id; // class variable
	Main Main_class = new Main(); // Object Of Main Class
	
	// FXML Area
	@FXML
	private PasswordField idfield; 		// Declare Fxml Component by Id
	@FXML
	private Button btnsubmit,btnback; 	// Declare Fxml Component by Id
	
	public void Button_Action(ActionEvent event) { // Method For Button in Fxml file
		if (event.getSource()  == btnsubmit) {
			reset_password(); //  Run A Method
		}else if (event.getSource() == btnback) {
			// Set Value of Fxml  Component based its id
			//  codes = id + Method
			idfield.setText("");	
			
			window.setScene(layer_in_stage); // move to login Page
		}
	}
	
	public void reset_password() { // method to reset password	
		id = idfield.getText(); // fill variable class value from idfield Passwordfield
		try {
            // RETURN VALUE OBJECT DRIVER 
            Class.forName(DRIVER);

            // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
            // c is a object from Conecctor class
            //dm is object from Conecctor class that run the function(getConnection) and set the parameters
            c = dm.getConnection(DB_URL, USER, PASS);

            // buat objek statement
            // s is a object from Conecctor class
            //dm is object from Conecctor class that run the function(createStatement) 
            s = c.createStatement();
            
            // difine Resultset as statment to exucute query to admin table
            // r is Resultset object
            r = s.executeQuery("SELECT * FROM admin WHERE id_admin='"+id+"'");
            
            if (r.next()) { // options for futher process
				if (id.equals(r.getString("id_admin"))) {
					idfield.setText(""); 		// Set Value For The Fxml Component
					window.setScene(layer_in_stage4); 	// move to Reset_Ui.fxml
				}
			}
            else {
            	text="ID ADMIN WAS NOT FOUND"; // Set Value Of Main Class Variable
            	Main_class.login(); 	// Run Main Class Method By Its Object
            	idfield.setText(""); 	// Set Value For The Fxml Component
			}
		} catch (Exception e) {
			e.printStackTrace(); // catch error
		}
	}
}
