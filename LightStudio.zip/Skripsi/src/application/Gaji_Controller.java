package application;


//IMPORT ATTRIBUTES FROM MY OWN CLASS
import static application.Koneksi.*;
import static application.Main.*;
import static application.Login_Controller.*;

import java.net.URL;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;
import java.util.ResourceBundle;

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.VerticalAlignment;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class Gaji_Controller implements Initializable {
	// location to save pdf file
	static final String location = "C:\\Users\\Fajar\\Documents\\Light Studio\\Report\\Pengeluaran gaji.pdf";
	// Create Object for Main Class
	Main Main_class = new Main(); 
	// Class Variable
	static String Kode;
	static String status_options="";
	static String kelamin_options="";
	
	//  FXML CODES AREA
	@FXML
	private Label username,status;
	@FXML
	private Button pembelian_btn,barang_btn,penjualan_btn,gaji_karyawan_btn,pendapatan_btn,update_btn,show_btn,
	suplier_btn,karyawan_btn,admin_btn,keluar_btn,search_btn,pdf_button,input_btn,hapus_btn,delete_btn;
	@FXML
	private TableView<Gaji> table;
	@FXML
	private TableColumn<Gaji, String> id_gaji_col,nama_penerima_col,total_gaji_col,tanggal_pemberian_col;
	@FXML
	private TextField id_gaji_field,nama_penerima_field,total_gaji_field,search_field;
	@FXML
	private DatePicker Tanggal;
	
	// Over Write Method 
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		Tanggal.setValue(LocalDate.now());
	}
	
	//Methos For Buttons of FXML File
	public void Button_Action(ActionEvent event) {
		if (event.getSource() == penjualan_btn) {
			Direktur_Controller Direktur_Controller_Object = fxml_file2.getController(); // Object Controller Class		
			// Run Method From Other Controllers
			Direktur_Controller_Object.show_name();
			Direktur_Controller_Object.show_data();			
			window.setScene(layer_in_stage2); //Move to Penjualan Page
		}else if (event.getSource() == barang_btn) {
			Barang_Controller Barang_Controller_Object = fxml_file10.getController();	
			Barang_Controller_Object.show_name();// Run Method From Other Controllers
			Barang_Controller_Object.show_data();
			window.setScene(layer_in_stage10); //Move to Barang Page
		}else if (event.getSource() == pembelian_btn) {
			Pembelian_Controller Pembelian_Controller_Object = fxml_file9.getController();	
			Pembelian_Controller_Object.show_name();// Run Method From Other Controllers
			Pembelian_Controller_Object.show_data();
			window.setScene(layer_in_stage9); //Move to Pembelian Page
		}else if (event.getSource() == gaji_karyawan_btn) {
			Gaji_Controller Gaji_Controller_Object = fxml_file8.getController();	
			Gaji_Controller_Object.show_name();// Run Method From Other Controllers
			Gaji_Controller_Object.show_data();
			window.setScene(layer_in_stage8); //Move to Gaji Page
		}else if (event.getSource() == pendapatan_btn) {
			Pendapatan_Controller Pendapatan_Controller_Object = fxml_file12.getController();
			Pendapatan_Controller_Object.MODAL(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.PENGELUARAN_GAJI(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.OMSET(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.MOENY(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.show_data(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.show_name(); // RUN METHOD FROM OTHER CONTROLLER
			window.setScene(layer_in_stage12); //Move to Pendapatan Page
		}else if (event.getSource() == suplier_btn) {
			// Object Controller Class
			Suplier_Controller Suplier_Controller_Object = fxml_file5.getController();	
			Suplier_Controller_Object.show_name();// Run Method From Other Controllers
			Suplier_Controller_Object.show_data();	
			window.setScene(layer_in_stage5); //Move to Suplier Page
		}else if (event.getSource() == karyawan_btn) {
			// Object Controller Class
			Karyawan_Controller Karyawan_Controller_Object = fxml_file6.getController();	
			Karyawan_Controller_Object.show_name();// Run Method From Other Controllers
			Karyawan_Controller_Object.show_data();// Run Method From Other Controllers
			window.setScene(layer_in_stage6); //Move to Karyawan Page			
		}else if (event.getSource() == admin_btn) {
			// Object Controller Class
			Admin_Controller Admin_Controller_Object = fxml_file7.getController();	
			Admin_Controller_Object.show_name();// Run Method From Other Controllers
			Admin_Controller_Object.show_data();// Run Method From Other Controllers
			window.setScene(layer_in_stage7); //Move to Admin Page
		}else if (event.getSource() == keluar_btn) {
			window.setX(350);
			window.setY(170);
			window.setScene(layer_in_stage);
			login_username =""; 
		}
		else if (event.getSource() == search_btn) {
			search_data();
		}
		else if (event.getSource() == pdf_button) {
			Create_pdf(); 
		}
		else if (event.getSource() == input_btn) {
			input_data();  
		}
		else if (event.getSource() == hapus_btn) {
			clear_textfield(); // run method
		}
		else if (event.getSource() == delete_btn) {
			delete(); // run method
		}else if (event.getSource() == update_btn) {
			update(); // run method
		}else if (event.getSource() == show_btn) {
			show(); // run method
		}
	}
				
	//method to show admin's name
	public void show_name() { 
		username.setText(login_username);
		status.setText(index);
	}

	// method for table view
	public ObservableList<Gaji> list_data(){ // non void method, to get data from database and set to observableArrayList()
		ObservableList<Gaji> data =FXCollections.observableArrayList();// container for the data
		try {
	        // RETURN VALUE OBJECT DRIVER 
	        Class.forName(DRIVER);
	
	        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	        // c is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	        c = dm.getConnection(DB_URL, USER, PASS);
	
	        // buat objek statement
	        // s is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(createStatement) 
	        s = c.createStatement();
	        
	        // difine Resultset as statment to exucute query to suppliers table
	        // r is Resultset object
	        r = s.executeQuery("SELECT * FROM gaji_karyawan");
	        	        
	        while (r.next()) {
	        	// LOCAL VARIABLE
        		Double currency = new Double(r.getString("TOTAL_GAJI")); 
        		String currencyOut;
        		
	        	NumberFormat currencyFormatter; // OBJECT OF NUMBERFORMAT CLASS 				            
	            Locale s = new Locale("id", "ID");// OBJECT OF LOCALE		            
	            currencyFormatter = NumberFormat.getCurrencyInstance(s); // RUN METHOD 		            
	            currencyOut = currencyFormatter.format(currency); // RUN METHOD
	        	
	        	// get data from database and set constructor of suppliers class
	        	Gaji gaji_object = new Gaji(r.getString("ID_GAJI"),r.getString("NAMA_PENERIMA"),currencyOut,r.getString("TANGGAL_PEMBERIAN"));
	        	data.add(gaji_object);// set data object to get data from admin object 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data; // return ObservableListvalue			
	} 
	
	// method to show data to the table
	public void show_data(){
		try {
			ObservableList<Gaji> list = list_data(); // create ObservableList object and run list_data method 
			table.setItems(list); // set data of ObservableList<Karyawan> to the table
			id_gaji_col.setCellValueFactory(new PropertyValueFactory<Gaji, String>("Id_Gaji"));// display value to the column 
			nama_penerima_col.setCellValueFactory(new PropertyValueFactory<Gaji, String>("Nama_Penerima"));// display value to the column 
			total_gaji_col.setCellValueFactory(new PropertyValueFactory<Gaji, String>("Total_gaji"));// display value to the column 
			tanggal_pemberian_col.setCellValueFactory(new PropertyValueFactory<Gaji, String>("Tanggal_Pemberian"));// display value to the column 		
		} 	
		catch (Exception e) {				
			System.out.print("show data is error");
			e.printStackTrace();
		}
	}	// method to show data to the table
	
	// Delete Method
	public void delete() {
		if (table.getSelectionModel().isSelected(table.getSelectionModel().getSelectedIndex())) {
			Gaji selected_item = table.getSelectionModel().getSelectedItem();
		      try {
		      // RETURN VALUE OBJECT DRIVER 
		      Class.forName(DRIVER);
		
		      // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
		      // c is a object from Conecctor class
		      //dm is object from Conecctor class that run the function(getConnection) and set the parameters
		      c = dm.getConnection(DB_URL, USER, PASS);
		
		      // buat objek statement
		      // s is a object from Conecctor class
		      //dm is object from Conecctor class that run the function(createStatement) 
		      s = c.createStatement();
		      r = s.executeQuery("SELECT * FROM gaji_karyawan WHERE ID_GAJI='"+selected_item.getId_Gaji()+"'");
		      if (r.next()) {
		          s.executeUpdate("DELETE FROM gaji_karyawan WHERE ID_GAJI='"+selected_item.getId_Gaji()+"'");
		          text = selected_item.getId_Gaji()+" HAS DELETED"; // set Main class variable
		          Main_class.login(); // run method from Main class
		          clear_textfield(); // run method
		          show_data(); // run method
		      }
		      else{
		      	text = "THE ID WAS NOT FOUND"; // set Main class variable
		      	Main_class.login(); // run method from Main class 
		          clear_textfield(); // run method
		      }
		  }
		  catch (Exception e) {
		      e.printStackTrace();
		  }
		}
		else {
			text ="Baris Table Belum Di Pilih";
			Main_class.login();
		}
	}
	
	// method to check a variable is numeric or not
	public static boolean isNumeric(String str) { 
        return str != null && str.matches("[-+]?\\d*\\.?\\d+");
    }
		
	// method to input data to the database
    public void input_data() { 	   	
    	// method variable
        String nama_penerima = nama_penerima_field.getText();
        String total_gaji = total_gaji_field.getText();
        LocalDate tanggal_storage = Tanggal.getValue();
	                
        try {          
        	//Count Characters of The variable
            int nama_penerima_lenght = nama_penerima.length(); 
            int total_gaji_lenght = total_gaji.length();
            
            // define the text field
            if (nama_penerima_lenght == 0) {  
            	text ="NAMA TIDAK BOLEH KOSONG"; // set Main class variable
            	Main_class.login();// run method from Main class
        	}
	            else if (nama_penerima_lenght > 50) {
	        		text ="JUMLAH KARAKTER NAMA_PENEIMA MELEBIHI 50 KATA"; // set Main class variable
	        		Main_class.login();// run method from Main class
				}
	            else if (isNumeric(nama_penerima) == true) {
					text ="NAMA TIDAK BOLEH MENGANDUNG ANGKA"; // set Main class variable
					Main_class.login();	// run method from Main class
	            }
		        //  
	            
	            // define the field
	            else if (total_gaji_lenght == 0) {
	            	text = "GAJI TIDAK BOLEH KOSONG"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}else if (total_gaji_lenght > 50) {
	            	text ="JUMLAH KARAKTER TOTAL GAJI MELEBIHI 50 KATA"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}else if (isNumeric(total_gaji) == false) {
					text ="TOTAL GAJI TIDAK BOLEH MENGANDUNG ALFABET"; // set Main class variable
					Main_class.login();	// run method from Main class
	            }
            	              	                            
            else {
            	Class.forName(DRIVER);
     	        c = dm.getConnection(DB_URL, USER, PASS);
     	        s = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
     	        r = s.executeQuery("SELECT * FROM gaji_karyawan");    
     	        r.last();
     	        
     	        if (r.getRow() == 0) {
     	        	String first_code = "G1";
     	        	//convert method variable to uppercase
     	        	String nama_penerima_uppercase = nama_penerima.toUpperCase();
                    //    
                      
                    String insert ="INSERT INTO gaji_karyawan VALUES"+"('"+first_code+"',"+"'"+nama_penerima_uppercase+"',"+"'"+total_gaji+"',"+"'"+tanggal_storage+"')";
                    s.execute(insert);
                    text = "DATA TELAH DI INPUT";	// set Main class variable
                    Main_class.login();				// run method from Main class
                    show_data(); 					// run method                    
                    clear_textfield();       	        	
				}     	        
     	        else {			
                	int kode = r.getRow();
                	String get_kode = r.getString("ID_GAJI");
                	String remove_code = get_kode.replace("G","");
                	int remove_code_to_string = Integer.parseInt(remove_code);  
                	int kode2 = kode + remove_code_to_string;
                	String final_code = "G"+String.valueOf(kode2);
					
					//convert method variable to uppercase
                	String nama_penerima_uppercase = nama_penerima.toUpperCase();   
                      
                    String insert ="INSERT INTO gaji_karyawan VALUES"+"('"+final_code+"',"+"'"+nama_penerima_uppercase+"',"+"'"+total_gaji+"',"+"'"+tanggal_storage+"')";
                    s.execute(insert);
                    text = "DATA TELAH DI INPUT";	// set Main class variable
                    Main_class.login();				// run method from Main class
                    show_data(); 					// run method                    
                    clear_textfield();
				}             	
            } // else       
        } //try 
		catch (Exception e) {
		    e.printStackTrace();
		}
    } // end of method to input data to the database
     
    // Update Method
    public void update() {  		        	
    	// method variable  	
    	 String nama_penerima = nama_penerima_field.getText();
         String total_gaji = total_gaji_field.getText();
         LocalDate tanggal_storage = Tanggal.getValue();
       
       try {
           // RETURN VALUE OBJECT DRIVER 
           Class.forName(DRIVER);

           // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
           // c is a object from Conecctor class
           //dm is object from Conecctor class that run the function(getConnection) and set the parameters
           c = dm.getConnection(DB_URL, USER, PASS);

           // buat objek statement
           // s is a object from Conecctor class
           //dm is object from Conecctor class that run the function(createStatement) 
           s = c.createStatement();
           
           r = s.executeQuery("SELECT * FROM gaji_karyawan WHERE ID_GAJI='"+Kode+"'");    	           
           if (r.next()) { 
        	   //Count Characters of The variable
        	   int nama_penerima_lenght = nama_penerima.length(); 
               int total_gaji_lenght = total_gaji.length();

               // define the text field
               if (nama_penerima_lenght == 0) {  
	               	text ="NAMA TIDAK BOLEH KOSONG"; // set Main class variable
	               	Main_class.login();// run method from Main class
           		}
	   	            else if (nama_penerima_lenght > 50) {
	   	        		text ="JUMLAH KARAKTER NAMA_PENEIMA MELEBIHI 50 KATA"; // set Main class variable
	   	        		Main_class.login();// run method from Main class
	   				}
	   	            else if (isNumeric(nama_penerima) == true) {
	   					text ="NAMA TIDAK BOLEH MENGANDUNG ANGKA"; // set Main class variable
	   					Main_class.login();	// run method from Main class
	   	            }
	   	            
	   	            // define the field
	   	            else if (total_gaji_lenght == 0) {
	   	            	text = "GAJI TIDAK BOLEH KOSONG"; // set Main class variable
	   	            	Main_class.login();// run method from Main class
	   				}else if (total_gaji_lenght > 50) {
	   	            	text ="JUMLAH KARAKTER TOTAL GAJI MELEBIHI 50 KATA"; // set Main class variable
	   	            	Main_class.login();// run method from Main class
	   				}else if (isNumeric(total_gaji) == false) {
	   					text ="TOTAL GAJI TIDAK BOLEH MENGANDUNG ALFABET"; // set Main class variable
	   					Main_class.login();	// run method from Main class
	   	            } 
               	                   
               else {
                   // convert method variable to uppercase
            	   String nama_penerima_uppercase = nama_penerima.toUpperCase();

                   // UPDATE
                   String insert ="UPDATE gaji_karyawan SET NAMA_PENERIMA ='"+nama_penerima_uppercase+"',TOTAL_GAJI ='"+total_gaji+"',TANGGAL_PEMBERIAN ='"+tanggal_storage+"' WHERE ID_GAJI='"+Kode+"'";
                   s.executeUpdate(insert);
                   text = "DATA TELAH DI UPDATE";//set attribut text from main class
                   Main_class.login();// run method from Main class
                   show_data();// run method show data
                   clear_textfield();
                   Kode ="";	
               }
           }
           else if (table.getSelectionModel().isSelected(table.getSelectionModel().getSelectedIndex())) {
        	  text = "Tekan Tombol Show"; // set attribut text from main class
         	  Main_class.login(); // run method from Main class   
           }
           else{
        	  text = "Baris Table Belum Di Pilih"; // set attribut text from main class
        	  Main_class.login(); // run method from Main class    
           }       
       } 
       catch (Exception e) {
           e.printStackTrace();
       }
	 } // end of update
    
    // method to clear textfields
	public void clear_textfield() {
		nama_penerima_field.setText("");
		total_gaji_field.setText("");
        search_field.setText("");
	}
	
    // method to clear textfields
	public void show() {
		if (table.getSelectionModel().isSelected(table.getSelectionModel().getSelectedIndex())) {	
			try {
				//Select Item From Table View
		    	Gaji selected_item = table.getSelectionModel().getSelectedItem();
		    	
				Kode =selected_item.getId_Gaji(); // get id from selected row
				
				// Set Value Of Forms In FXML File
				nama_penerima_field.setText(selected_item.getNama_Penerima());
				String get_tanggal  = selected_item.getTanggal_Pemberian();
				LocalDate tanggal_update = LocalDate.parse(get_tanggal);
				Tanggal.setValue(tanggal_update);
				
				Class.forName(DRIVER);
				c = dm.getConnection(DB_URL, USER, PASS);
				s = c.createStatement();
				r = s.executeQuery("SELECT * FROM gaji_karyawan WHERE ID_GAJI='"+Kode+"'");
				r.next();
				
				// Set Value Of Forms In FXML File
				total_gaji_field.setText(r.getString("TOTAL_GAJI"));

			} catch (Exception e) {
				// TODO: handle exception
			}
		}else {
			text = "Pilih Baris Table Terlebih Dahulu";
			Main_class.login();
		}	
	}
	
	// method to search data
	public void search_data() {
		ObservableList<Gaji> search_data = FXCollections.observableArrayList();
		try {
            // RETURN VALUE OBJECT DRIVER 
            Class.forName(DRIVER);

            // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
            // c is a object from Conecctor class
            //dm is object from Conecctor class that run the function(getConnection) and set the parameters
            c = dm.getConnection(DB_URL, USER, PASS);

            // buat objek statement
            // s is a object from Conecctor class
            //dm is object from Conecctor class that run the function(createStatement) 
            s = c.createStatement();
            
            String get_search_field = search_field.getText();
            
            r = s.executeQuery("SELECT * FROM gaji_karyawan WHERE NAMA_PENERIMA='"+get_search_field+"'");           
            while (r.next()) {
            	
	        	// get data from database and set constructor of Admin class
            	Gaji gaji_object = new Gaji(r.getString("ID_GAJI"),r.getString("NAMA_PENERIMA"),r.getString("TOTAL_GAJI"),r.getString("TANGGAL_PEMBERIAN"));
            	search_data.add(gaji_object);// set data object to get data from admin object                 
            }
            			
			table.setItems(search_data); // set data of ObservableList<Admin> to the table 
			id_gaji_col.setCellValueFactory(new PropertyValueFactory<Gaji, String>("Id_Gaji"));// display value to the column 
			nama_penerima_col.setCellValueFactory(new PropertyValueFactory<Gaji, String>("Nama_Penerima"));// display value to the column 
			total_gaji_col.setCellValueFactory(new PropertyValueFactory<Gaji, String>("Total_gaji"));// display value to the column 
			tanggal_pemberian_col.setCellValueFactory(new PropertyValueFactory<Gaji, String>("Tanggal_Pemberian"));// display value to the column 			
		} catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	// method to create pdf
	public void Create_pdf() {
		 try {                      
	            // RETURN VALUE OBJECT DRIVER 
	            Class.forName(DRIVER);

	            // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	            // c is a object from Conecctor class
	            //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	            c = dm.getConnection(DB_URL, USER, PASS);

	            // buat objek statement
	            // s is a object from Conecctor class
	            //dm is object from Conecctor class that run the function(createStatement) 
	            s = c.createStatement();
	           
	            //String search_pdf = search.getText();// get String 
	            
	            // set location 
	            r = s.executeQuery("SELECT * FROM gaji_karyawan");
	            
	            // Initialize PDF document
	            PdfDocument pdf = new PdfDocument(new PdfWriter(location));                  
	           
	            // Creating a Document object       
	            Document doc = new Document(pdf);
	            
	          //CREATING AN IMAGETAE OBJECT
 			String imFile = "C:\\Users\\Fajar\\eclipse-workspace\\Skripsi\\src\\images\\logo.png";
 			ImageData data = ImageDataFactory.create(imFile);
 		//
 
 		// CREATING AN IMAGE OBJECT
 			Image image = new Image(data).setHeight(50).setWidth(50).setFixedPosition(270, 765);
 		//
	            
	             // Creating a table 
	            float [] pointColumnWidths = {150F,150F,150F,150F};  
	            Table table = new Table(pointColumnWidths);
	            table.setRelativePosition(0, 150, 0, 0);
	            
	            //add font object
	            PdfFont bold = PdfFontFactory.createFont(StandardFonts.TIMES_BOLD);
	            
	         // adding cells to the table
     		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("ID").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
     		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("NAMA PENERIMA").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
     		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("TOTAL GAJI").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
     		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("TANGGAL PEMBERIAN").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
     	//
	            
	            while (r.next()) {
	            
	            // DEFINE LOCAL VARIABLE 
	            String A = r.getString("ID_GAJI");
	            String B = r.getString("NAMA_PENERIMA");
	            String C = r.getString("TOTAL_GAJI");
	            String D = r.getString("TANGGAL_PEMBERIAN");
	            
	            // Adding cells to the table
	            table.addCell(new Cell().add(new Paragraph(A).setFontSize(8)));
	            table.addCell(new Cell().add(new Paragraph(B).setFontSize(8))); 
	            table.addCell(new Cell().add(new Paragraph(C).setFontSize(8))); 
	            table.addCell(new Cell().add(new Paragraph(D).setFontSize(8)));
	            }
	            
	         // HEADER
	            Text title2 = new Text("TB CHANDRA")
	            	.setFont(PdfFontFactory.createFont(StandardFonts.HELVETICA))
	        		.setFontSize(11).setBold();
	            Text title3 = new Text("Jl. Kemang, Sukatani, Kec. Tapos, Kota Depok, Jawa Barat 16454")
	            	.setFont(PdfFontFactory.createFont(StandardFonts.HELVETICA))
	            	.setFontSize(9);
	            Paragraph header = new Paragraph(title2);
	            Paragraph header2 = new Paragraph(title3);
	        //
         
         // set the text to the document
     		Text line = new Text("============================================================================");
     		Text title4 = new Text("LAPORAN PENGELUARAN GAJI").setBold().setFontSize(12);  
     		Paragraph Line = new Paragraph(line);
     		Paragraph paragraph = new Paragraph(title4);
     		
     		LocalDate pdfdate = LocalDate.now();
     		String name = "";
     		String ind_date = pdfdate.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL));
     		Paragraph currenttime2 = new Paragraph("Depok, "+ind_date + " \n  Direktur \n \n \n  (Chandra Kurniawan)").setRelativePosition(170, 180, 0, 0);
     		currenttime2.setTextAlignment(TextAlignment.CENTER);
     	//
     		doc.add(image);
     		doc.add(table);
     		doc.add(currenttime2);
     		
         for (int i = 1; i <= pdf.getNumberOfPages(); i++) { // LOOP FOOTER FOR EACH PAGE
				Rectangle dd = pdf.getPage(i).getPageSize(); // GET PAGE NUMBER 
				
				float x = dd.getWidth() / 2;
				float y = dd.getTop() - 100;
				
				float x2 = dd.getWidth() / 2;
				float y2 = dd.getTop() - 125;
				
				float x3 = dd.getWidth() / 2;
				float y3 = dd.getTop() - 145;
				
				float x4 = dd.getWidth() / 2;
				float y4 = dd.getTop() - 165;
				
				float x5 = dd.getWidth() / 2;
				float y5 = dd.getTop() - 185;
							
				doc.showTextAligned(header,x, y, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
				doc.showTextAligned(header2,x2, y2, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);        
				doc.showTextAligned(Line,x3,y3, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
				doc.showTextAligned(paragraph,x4, y4, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
				doc.showTextAligned(Line,x5,y5, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);								
			}
         //	            
	            // notif
	            text =" Pdf Telah Dibuat";	// set Main class variable
	            Main_class.login(); 	// run Main class method
	            doc.close();	// close document         
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		}
		// method to create pdf
		
}
