package application;

import static application.Koneksi.*;
public class Check_Connection {
	
	public static void main(String[] args) {
		try {
			Class.forName(DRIVER);
			c = dm.getConnection(DB_URL,USER,PASS);
			
			s = c.createStatement();
			
			r = s.executeQuery("SELECT * FROM admin");
			
			while(r.next()) {
				System.out.println(r.getString("id_admin"));
				
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
