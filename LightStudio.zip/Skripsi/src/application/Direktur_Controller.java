package application;


//IMPORT ATTRIBUTES FROM MY OWN CLASS
import static application.Koneksi.*;
import static application.Main.*;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Iterator;
import java.util.Locale;
import java.util.ResourceBundle;

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.VerticalAlignment;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import static application.Login_Controller.*;

public class Direktur_Controller implements Initializable {
	// location to save pdf file
		static final String location = "C:\\Users\\Fajar\\Documents\\Light Studio\\Report\\nota penjualan.pdf";
	Main Main_class = new Main(); // Create Object for Main Class
	
	// Class Variable
	static String Kode,barang_dibeli,total3,get_id_barang,first_code,final_code;
	static int jumlah_dibeli, harga_item,harga_item_final;
	static int total2 = 0;
	static String final_stuff2="";
	static String jarak="";	
	static ObservableList<Record_data> record2 = FXCollections.observableArrayList();
	static int array_number = 0;
	String newline ="";
	
	// Aray
	int[] jml_dibeli = new int[1000];
	String[] store_id_barang = new String[1000];
	
	//  FXML CODES AREA
	@FXML
	private Label username,status;
	@FXML
	private Button pembelian_btn,barang_btn,penjualan_btn,gaji_karyawan_btn,pendapatan_btn,bayar_btn,
	suplier_btn,karyawan_btn,admin_btn,keluar_btn,search_btn,search_to_pdf_button,tambah_btn,batalkan_btn,riwayat_btn;
	@FXML
	private DatePicker date;
	@FXML
	private TableView<Penjualan> table;
	@FXML
	private TableView<Record_data> record_table;
	@FXML 
	private TableColumn<Penjualan, String> id_barang_col,barang_col,jenis_barang_col,harga_satuan_col,stock_col;
	@FXML
	private TableColumn<Record_data, String> jml_record_col,barang_record_col,harga_record_col;
	@FXML
	private TextField search_field,jumlah_field,display_total;
	
	// Over Write Method 
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		date.setValue(LocalDate.now());
	}
	
	//Methos For Buttons of FXML File
	public void Button_Action(ActionEvent event) {
		if (event.getSource() == penjualan_btn) {
			Direktur_Controller Direktur_Controller_Object = fxml_file2.getController(); // Object Controller Class		
			// Run Method From Other Controllers
			Direktur_Controller_Object.show_name();
			Direktur_Controller_Object.show_data();			
			window.setScene(layer_in_stage2); //Move to Penjualan Page
		}else if (event.getSource() == barang_btn) {
			Barang_Controller Barang_Controller_Object = fxml_file10.getController();	
			Barang_Controller_Object.show_name();// Run Method From Other Controllers
			Barang_Controller_Object.show_data();
			window.setScene(layer_in_stage10); //Move to Barang Page
		}else if (event.getSource() == pembelian_btn) {
			Pembelian_Controller Pembelian_Controller_Object = fxml_file9.getController();	
			Pembelian_Controller_Object.show_name();// Run Method From Other Controllers
			Pembelian_Controller_Object.show_data();
			window.setScene(layer_in_stage9); //Move to Pembelian Page
		}else if (event.getSource() == gaji_karyawan_btn) {
			Gaji_Controller Gaji_Controller_Object = fxml_file8.getController();	
			Gaji_Controller_Object.show_name();// Run Method From Other Controllers
			Gaji_Controller_Object.show_data();
			window.setScene(layer_in_stage8); //Move to Gaji Page
		}else if (event.getSource() == pendapatan_btn) {
			Pendapatan_Controller Pendapatan_Controller_Object = fxml_file12.getController();
			Pendapatan_Controller_Object.MODAL(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.PENGELUARAN_GAJI(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.OMSET(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.MOENY(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.show_data(); // RUN METHOD FROM OTHER CONTROLLER
			Pendapatan_Controller_Object.show_name(); // RUN METHOD FROM OTHER CONTROLLER
			window.setScene(layer_in_stage12); //Move to Pendapatan Page
		}else if (event.getSource() == suplier_btn) {
			// Object Controller Class
			Suplier_Controller Suplier_Controller_Object = fxml_file5.getController();	
			Suplier_Controller_Object.show_name();// Run Method From Other Controllers
			Suplier_Controller_Object.show_data();	
			window.setScene(layer_in_stage5); //Move to Suplier Page
		}else if (event.getSource() == karyawan_btn) {
			// Object Controller Class
			Karyawan_Controller Karyawan_Controller_Object = fxml_file6.getController();	
			Karyawan_Controller_Object.show_name();// Run Method From Other Controllers
			Karyawan_Controller_Object.show_data();// Run Method From Other Controllers
			window.setScene(layer_in_stage6); //Move to Karyawan Page			
		}else if (event.getSource() == admin_btn) {
			// Object Controller Class
			Admin_Controller Admin_Controller_Object = fxml_file7.getController();	
			Admin_Controller_Object.show_name();// Run Method From Other Controllers
			Admin_Controller_Object.show_data();// Run Method From Other Controllers
			window.setScene(layer_in_stage7); //Move to Admin Page
		}else if (event.getSource() == keluar_btn) {
			window.setX(350);
			window.setY(170);
			window.setScene(layer_in_stage);
			login_username =""; 
		}else if (event.getSource() == search_btn) {
			search_data();
		}else if (event.getSource() == search_to_pdf_button) {
			System.out.println("Search to Pdf"); 
		}else if (event.getSource() == tambah_btn) {
			tambah();
		}else if (event.getSource() == batalkan_btn) {
			batal_pembelian();
		}else if (event.getSource() == bayar_btn) {
			pay();
		}else if (event.getSource() == riwayat_btn) {
			Main_class.Riwayat_Penjualan_stage();
		}
	}
				
	//method to show admin's name
	public void show_name() { 
		username.setText(login_username);
		status.setText(index);
	}
	
	//  Method To Visible FXML Components
	public void BUTTONS_VISIBLE() {
        if (index.equals("KARYAWAN")) {
        	// set visible for menu buttons
        	gaji_karyawan_btn.setVisible(false);
        	pendapatan_btn.setVisible(false);
        	suplier_btn.setVisible(false);
        	karyawan_btn.setVisible(false);
        	admin_btn.setVisible(false);	        	
		}else if (index.equals("DIREKTUR")) {
			// set visible for menu buttons
        	gaji_karyawan_btn.setVisible(true);
        	pendapatan_btn.setVisible(true);
        	suplier_btn.setVisible(true);
        	karyawan_btn.setVisible(true);
        	admin_btn.setVisible(true);	
		}
	}
	
	// method for table view
	public ObservableList<Penjualan> list_data(){ // non void method, to get data from database and set to observableArrayList()
		ObservableList<Penjualan> data =FXCollections.observableArrayList();// container for the data
		try {
	        // RETURN VALUE OBJECT DRIVER 
	        Class.forName(DRIVER);
	
	        // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
	        // c is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(getConnection) and set the parameters
	        c = dm.getConnection(DB_URL, USER, PASS);
	
	        // buat objek statement
	        // s is a object from Conecctor class
	        //dm is object from Conecctor class that run the function(createStatement) 
	        s = c.createStatement();
	        
	        // difine Resultset as statment to exucute query to suppliers table
	        // r is Resultset object
	        r = s.executeQuery("SELECT * FROM barang");
	        	        
	        while (r.next()) {
	        	// LOCAL VARIABLE
        		Double currency = new Double(r.getString("harga_jual")); 
        		String currencyOut;
        		
	        	NumberFormat currencyFormatter; // OBJECT OF NUMBERFORMAT CLASS 				            
	            Locale s = new Locale("id", "ID");// OBJECT OF LOCALE		            
	            currencyFormatter = NumberFormat.getCurrencyInstance(s); // RUN METHOD 		            
	            currencyOut = currencyFormatter.format(currency); // RUN METHOD
	        	
	        	// get data from database and set constructor of suppliers class
	        	Penjualan Penjualan_object = new Penjualan(r.getString("id_barang"),r.getString("nama_barang"),r.getString("jenis_barang"),currencyOut,r.getString("jumlah_barang"));
	        	data.add(Penjualan_object);// set data object to get data from admin object 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data; // return ObservableListvalue			
	} 
		
	// method to show data to the table
	public void show_data(){
		try {
			ObservableList<Penjualan> list = list_data(); // create ObservableList object and run list_data method 
			table.setItems(list); // set data of ObservableList<Karyawan> to the table
			id_barang_col.setCellValueFactory(new PropertyValueFactory<Penjualan, String>("Id_Barang"));// display value to the column 
			barang_col.setCellValueFactory(new PropertyValueFactory<Penjualan, String>("Nama_Barang"));// display value to the column 
			jenis_barang_col.setCellValueFactory(new PropertyValueFactory<Penjualan, String>("Jenis_Barang"));// display value to the column 
			harga_satuan_col.setCellValueFactory(new PropertyValueFactory<Penjualan, String>("Harga_Jual"));// display value to the column 
			stock_col.setCellValueFactory(new PropertyValueFactory<Penjualan, String>("Jumlah_Barang"));// display value to the column
		} 	
		catch (Exception e) {				
			System.out.print("show data is error");
			e.printStackTrace();
		}
	}	// method to show data to the table
	
	// method to search data
	public void search_data() {
		ObservableList<Penjualan> search_data = FXCollections.observableArrayList();
		try {
            // RETURN VALUE OBJECT DRIVER 
            Class.forName(DRIVER);

            // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
            // c is a object from Conecctor class
            //dm is object from Conecctor class that run the function(getConnection) and set the parameters
            c = dm.getConnection(DB_URL, USER, PASS);

            // buat objek statement
            // s is a object from Conecctor class
            //dm is object from Conecctor class that run the function(createStatement) 
            s = c.createStatement();
            
            String get_search_field = search_field.getText();
            
            r = s.executeQuery("SELECT * FROM barang WHERE jenis_barang='"+get_search_field+"' OR nama_barang='"+get_search_field+"'");           
            while (r.next()) {
            	Double currency = new Double(r.getString("harga_jual")); 
        		String currencyOut;
        		
	        	NumberFormat currencyFormatter; // OBJECT OF NUMBERFORMAT CLASS 				            
	            Locale s = new Locale("id", "ID");// OBJECT OF LOCALE		            
	            currencyFormatter = NumberFormat.getCurrencyInstance(s); // RUN METHOD 		            
	            currencyOut = currencyFormatter.format(currency); // RUN METHOD
	        	
	         // get data from database and set constructor of suppliers class
	        	Penjualan Penjualan_object = new Penjualan(r.getString("id_barang"),r.getString("nama_barang"),r.getString("jenis_barang"),currencyOut,r.getString("jumlah_barang"));
	        	search_data.add(Penjualan_object);// set data object to get data from admin object                 
            }
            			
			table.setItems(search_data); // set data of ObservableList<Admin> to the table 
			id_barang_col.setCellValueFactory(new PropertyValueFactory<Penjualan, String>("Id_Barang"));// display value to the column 
			barang_col.setCellValueFactory(new PropertyValueFactory<Penjualan, String>("Nama_Barang"));// display value to the column 
			jenis_barang_col.setCellValueFactory(new PropertyValueFactory<Penjualan, String>("Jenis_Barang"));// display value to the column 
			harga_satuan_col.setCellValueFactory(new PropertyValueFactory<Penjualan, String>("Harga_Jual"));// display value to the column 
			stock_col.setCellValueFactory(new PropertyValueFactory<Penjualan, String>("Jumlah_Barang"));// display value to the column		
		} catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	// method to check a variable is numeric or not
	public static boolean isNumeric(String str) { 
        return str != null && str.matches("[-+]?\\d*\\.?\\d+");
    }
	
	// Tambah Method		
	public void tambah() {
		if (table.getSelectionModel().isSelected(table.getSelectionModel().getSelectedIndex())) {	
			try {
				//local variable
				String jumlah_field_var = jumlah_field.getText();
				int jumlah_field_lenght = jumlah_field_var.length();
				
				// Options
				if (jumlah_field_lenght == 0) {
					text ="JUMLAH TIDAK BOLEH KOSONG"; // set Main class variable
	            	Main_class.login();// run method from Main class
				}
					else if (isNumeric(jumlah_field_var) == false) {
						text ="JUMLAH TIDAK BOLEH ALFABET"; // set Main class variable
		            	Main_class.login();// run method from Main class
					}
				else {
					//Select Item From Table View
			    	Penjualan selected_item = table.getSelectionModel().getSelectedItem();
			    	
					Kode =selected_item.getId_Barang(); // get id from selected row
					
					Class.forName(DRIVER);
					c = dm.getConnection(DB_URL, USER, PASS);
					s = c.createStatement();
					r = s.executeQuery("SELECT * FROM barang WHERE id_barang='"+Kode+"'");
					if (r.next()) {
						// Set Value Of class variable
						jumlah_dibeli = Integer.parseInt(jumlah_field.getText());
						barang_dibeli = r.getString("nama_barang"); // get value from the database
						harga_item  = Integer.parseInt(r.getString("harga_jual")); // get value from the database
						get_id_barang =  r.getString("id_barang");
						int int_stock = Integer.parseInt(r.getString("jumlah_barang")); // get value from the database
						int kurangi_stock = int_stock - jumlah_dibeli;
						harga_item_final = harga_item * jumlah_dibeli;
						
						final_stuff2 =final_stuff2+""+newline+" "+jumlah_dibeli+"   "+barang_dibeli;
						newline = System.lineSeparator();
						//jarak ="|";
						
		        		// LOCAL VARIABLE
	        			Double currency = new Double(harga_item_final); 
	        			String currencyOut;
		    
	        			// CURRENCY METHOD
		        		NumberFormat currencyFormatter; // OBJECT OF NUMBERFORMAT CLASS 				            
		        		Locale region = new Locale("id", "ID");// OBJECT OF LOCALE		            
		        		currencyFormatter = NumberFormat.getCurrencyInstance(region); // RUN METHOD 		            
		        		currencyOut = currencyFormatter.format(currency); // RUN METHOD
						
						// set value to constructor of Record_data	
						Record_data Record_data_object = new Record_data(jumlah_dibeli,barang_dibeli,currencyOut);
						
						// ADD VALUE TO OBSERVABLE LIST FROM RECORD_DATA
						record2.add(Record_data_object);
						
						// SET VALUE TO RECORD_TABLE
						record_table.setItems(record2); 
						
						// DISPLAY VALUES TO EACH COLUMN	
						jml_record_col.setCellValueFactory(new PropertyValueFactory<Record_data,String>("Amount"));
						barang_record_col.setCellValueFactory(new PropertyValueFactory<Record_data,String>("Stuff"));
						harga_record_col.setCellValueFactory(new PropertyValueFactory<Record_data,String>("Price"));
						
						// SET VALUE OF DISPLAY_TOTAL			
		        			// LOCAL VARIABLE
							total2 = total2 + harga_item_final; // local variable
							total3 = Integer.toString(total2); // convert int to String
							Double currency2 = new Double(total3);  
	        				String currencyOut2;
	        				
	        				// CURRENCY METHOD
		        			NumberFormat currencyFormatter2; 	// OBJECT OF NUMBERFORMAT CLASS 				            
		        			Locale s2 = new Locale("id", "ID");	// OBJECT OF LOCALE		            
		        			currencyFormatter2 = NumberFormat.getCurrencyInstance(s2); 	 // RUN METHOD 		            
		        			currencyOut2 = currencyFormatter2.format(currency2); 		 // RUN METHOD
		        			
		        			display_total.setText(currencyOut2); // set value to display_total	
		        		//
											
						// STORE VALUE IN ARRAY AFTER CLICK TAMBAH BUTTON
		        		store_value();
		     	
		        		// UPDATE STOCK IN BARANG TABLE
		        		String update ="UPDATE barang SET jumlah_barang ='"+kurangi_stock+"' WHERE id_barang='"+Kode+"'";
		        		s.executeUpdate(update);
		        		
		        		// REFERSH DATA BARANG
		        		show_data();
		        		
						// CLEAR THE TEXT FIELDS
						search_field.setText("");
						jumlah_field.setText("");
					}
				}

			} catch (Exception e) {
				// TODO: handle exception
			}
		}else {
			text = "Pilih Baris Table Terlebih Dahulu";
			Main_class.login();
		}	
	}
	
	//STORE VALUE METHOD CONNECTED WITH TAMBAH METHOD
	public void store_value() {
		jml_dibeli[array_number] = jumlah_dibeli;
		store_id_barang[array_number] = get_id_barang;
		//System.out.println(jml_dibeli[array_number]);
		//System.out.println(store_id_barang[array_number]);
		array_number = array_number + 1;
	}
	
	public void batal_pembelian(){
		
		//LOCAL VARIABLE
		int get_jml_beli;
		String get_store_id_barang;
		
		// RESTORE JUMLAH BARANG OR STOCK
		for (int i = 0; i < array_number; i++) {	
			try {
				// LOCAL VARABLE
				get_jml_beli = jml_dibeli[i];
				get_store_id_barang = store_id_barang[i];
				
				// UPDATE STOCK
				Class.forName(DRIVER);
				c = dm.getConnection(DB_URL, USER, PASS);
				s = c.createStatement();
				r = s.executeQuery("SELECT * FROM barang WHERE id_barang='"+get_store_id_barang+"'");
				if (r.next()) {
					int restore_stock = Integer.parseInt(r.getString("jumlah_barang")) + get_jml_beli;
					String update ="UPDATE barang SET jumlah_barang ='"+restore_stock+"' WHERE id_barang='"+get_store_id_barang+"'";
		    		s.executeUpdate(update);

		    		// REFRESH BARANG
		    		show_data();
		    		
		    		// CLEAR
		    		Clear();
		    		
		    		//System.out.println(store_id_barang);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// RESET ARRAY NUMBER
		array_number = 0;
	}
	
	// CLEAR METHOD
	public void Clear() {
		//Reset variale 
		total2 = 0;
		final_stuff2="";
		newline ="";
		total3="";
		Kode="";
		jumlah_dibeli = 0;
		barang_dibeli = "";
		harga_item  = 0; 
		get_id_barang =  "";
		harga_item_final = 0;
		total2 = 0; 
		total3 = ""; 
		
		// CLEAR TEXFIELDS
		search_field.setText("");
		jumlah_field.setText("");
		
		// CLEAR TABLE
		record2.clear();
		
		// SET VALUE OF DISPLAY_TOTAL
		display_total.setText("");
	}
	
	// PAY METHOD
	public void pay() {
		try {
			// method variable
	        String total_harga = display_total.getText();
	        
	        //Count Characters of The variable
            int total_harga_lenght = total_harga.length();
            LocalDate get_data_value = date.getValue();
            
            // define the text field
            if (total_harga_lenght == 0) {  
            	text ="TOTAL HARGA MASIH KOSONG"; // set Main class variable
            	Main_class.login();// run method from Main class
        	}
            else {
            	// SET SQL
    			Class.forName(DRIVER);
    			c = dm.getConnection(DB_URL, USER, PASS);
    			s = c.createStatement();
    			s = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
     	        r = s.executeQuery("SELECT * FROM penjualan");    
     	        r.last();
     	        
     	        // WHEN THERE ISN'T ANY ROW IN TABLE
     	        if (r.getRow() == 0) {
     	        	first_code = "P1";  
                      
                    String insert ="INSERT INTO penjualan VALUES"+"('"+first_code+"',"+"'"+final_stuff2+"',"+"'"+total3+"',"+"'"+get_data_value+"')";
                    s.execute(insert);
//                    text = "DATA TELAH DI INPUT";	// set Main class variable
//                    Main_class.login();				// run method from Main class
                    show_data(); 					// run method                    
                    Clear();						// CLEAR  TEXTFIELDS AND RECORD TABLE
                    Create_pdf();
                   
				}
     	        else {
     	        	//LOCAL VAR
     	        	String get_kode = r.getString("id_penjualan");
                	String remove_code = get_kode.replace("P","");
                	int remove_code_to_string = Integer.parseInt(remove_code);  
                	
                	int kode2 = 1 + remove_code_to_string;
                	final_code = "P"+String.valueOf(kode2);
                	
                	String insert ="INSERT INTO penjualan VALUES"+"('"+final_code+"',"+"'"+final_stuff2+"',"+"'"+total3+"',"+"'"+get_data_value+"')";
                    s.execute(insert);
//                    text = "DATA TELAH DI INPUT";	// set Main class variable
//                    Main_class.login();				// run method from Main class
                    show_data(); 					// run method                    
                    Clear();						// CLEAR  TEXTFIELDS AND RECORD TABLE
                    Create_pdf();
				}
			}
	        	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// method to create pdf
		public void Create_pdf() {
			 try {
//				 if (first_code.equals("P1")) {
//					
//				}
		            // RETURN VALUE OBJECT DRIVER 
		            Class.forName(DRIVER);

		            // CREATE A CONNECTION TO THE DATABASE (UD_JEMBER)
		            // c is a object from Conecctor class
		            //dm is object from Conecctor class that run the function(getConnection) and set the parameters
		            c = dm.getConnection(DB_URL, USER, PASS);

		            // buat objek statement
		            // s is a object from Conecctor class
		            //dm is object from Conecctor class that run the function(createStatement) 
		            s = c.createStatement();
		           
		            //String search_pdf = search.getText();// get String 
		            
		            // set location 
		            r = s.executeQuery("SELECT * FROM penjualan WHERE id_penjualan='"+final_code+"'");
		            
		            // Initialize PDF document
		            PdfDocument pdf = new PdfDocument(new PdfWriter(location));                  
		           
		            // Creating a Document object       
		            Document doc = new Document(pdf);
		            
		          //CREATING AN IMAGETAE OBJECT
				String imFile = "C:\\Users\\Fajar\\eclipse-workspace\\Skripsi\\src\\images\\logo.png";
				ImageData data = ImageDataFactory.create(imFile);
			//

			// CREATING AN IMAGE OBJECT
				Image image = new Image(data).setHeight(50).setWidth(50).setFixedPosition(270, 765);
			//
		            
		             // Creating a table 
		            float [] pointColumnWidths = {200F,150F,150F};  
		            Table table = new Table(pointColumnWidths);
		            table.setRelativePosition(0, 150, 0, 0);
		            
		            //add font object
		            PdfFont bold = PdfFontFactory.createFont(StandardFonts.TIMES_BOLD);
		            
		         // adding cells to the table
	    		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("RIWAYAT PENJUALAN").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
	    		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("HARGA TOTAL").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
	    		table.addCell(new Cell().setBackgroundColor(ColorConstants.BLUE).setBorder(Border.NO_BORDER).add(new Paragraph("TANGGAL TRANSAKSI").setFontSize(10).setBold().setFontColor(ColorConstants.WHITE)));
	    	//
		            
		            while (r.next()) {
		            
		            // DEFINE LOCAL VARIABLE 
		            String B = r.getString("riwayat_penjualan");
		            String C = r.getString("harga_total");
		            String D = r.getString("tanggal_transaksi");
		            
		            // Adding cells to the table
		            table.addCell(new Cell().add(new Paragraph(B).setFontSize(8))); 
		            table.addCell(new Cell().add(new Paragraph(C).setFontSize(8))); 
		            table.addCell(new Cell().add(new Paragraph(D).setFontSize(8)));
		            }
		            
		         // HEADER
		            Text haha = new Text("Menjual Bahan Bangunan");
		            Text title2 = new Text("TB CHANDRA")
		            	.setFont(PdfFontFactory.createFont(StandardFonts.HELVETICA))
		        		.setFontSize(11).setBold();
		            Text title3 = new Text("Jl. Kemang, Sukatani, Kec. Tapos, Kota Depok, Jawa Barat 16454")
		            	.setFont(PdfFontFactory.createFont(StandardFonts.HELVETICA))
		            	.setFontSize(9);
		            Paragraph header = new Paragraph(title2);
		            Paragraph header2 = new Paragraph(title3);
		            Paragraph header3 = new Paragraph(haha);
		        //
	        
	        // set the text to the document
	    		Text line = new Text("============================================================================");
	    		Text title4 = new Text("NOTA No."+final_code).setBold().setFontSize(12); 
	    		Paragraph Line = new Paragraph(line);
	    		Paragraph paragraph = new Paragraph(title4);

	    		LocalDate pdfdate = LocalDate.now();
	    		String name = "";
	    		String ind_date = pdfdate.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL));
	     		Paragraph currenttime2 = new Paragraph("Depok, "+ind_date + " \n  Direktur \n \n \n  (Chandra Kurniawan)").setRelativePosition(170, 180, 0, 0);
	    		currenttime2.setTextAlignment(TextAlignment.CENTER);
	    	//
	    		doc.add(image);
	    		doc.add(table);
	    		doc.add(currenttime2);
	    		
	        for (int i = 1; i <= pdf.getNumberOfPages(); i++) { // LOOP FOOTER FOR EACH PAGE
					Rectangle dd = pdf.getPage(i).getPageSize(); // GET PAGE NUMBER 
					
					float x = dd.getWidth() / 2;
					float y = dd.getTop() - 100;
					
					float x1_5 = dd.getWidth() / 2;
					float y1_5 = dd.getTop() - 115;
					
					float x2 = dd.getWidth() / 2;
					float y2 = dd.getTop() - 125;
					
					float x3 = dd.getWidth() / 2;
					float y3 = dd.getTop() - 145;
					
					float x4 = dd.getWidth() / 2;
					float y4 = dd.getTop() - 165;
					
					float x5 = dd.getWidth() / 2;
					float y5 = dd.getTop() - 185;
					
					float x6 = dd.getWidth() / 2;
					float y6 = dd.getTop() - 205;
								
					doc.showTextAligned(header,x, y, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
					doc.showTextAligned(header2,x2, y2, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
					doc.showTextAligned(header3,x1_5, y1_5, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0); 
					doc.showTextAligned(Line,x3,y3, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
					doc.showTextAligned(paragraph,x4, y4, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);
					doc.showTextAligned(Line,x5,y5, i, TextAlignment.CENTER, VerticalAlignment.BOTTOM, 0);	
				}
	        //	            
		            // notif
		            text =" Pdf Telah Dibuat";	// set Main class variable
		            Main_class.login(); 	// run Main class method
		            doc.close();	// close document         
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
			}
}
