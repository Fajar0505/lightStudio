package application;

public class Gaji {
    // class variable
		private String ID_GAJI,NAMA_PENERIMA,TOTAL_GAJI,TANGGAL_PEMBERIAN;
	//
	
	public Gaji (String id_gaji, String nama_penerima, String total_gaji, String tanggal_pemberian) {
		this.ID_GAJI = id_gaji;
		this.NAMA_PENERIMA = nama_penerima;
		this.TOTAL_GAJI = total_gaji;
		this.TANGGAL_PEMBERIAN = tanggal_pemberian;
	}
	public String getId_Gaji() {
		return ID_GAJI;
	}
	public String getNama_Penerima() {
		return NAMA_PENERIMA;
	}
	public String getTotal_gaji() {
		return TOTAL_GAJI;
	}
	public String getTanggal_Pemberian() {
		return TANGGAL_PEMBERIAN;
	}
}
