package application;
	
import static application.Main.fxml_file7;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;


public class Main extends Application { //main class inherits 'Application class' from java fx
	
	// Create object class
	static Stage window,window2,window3; // Modifier,class,object
	static Parent fxml_control,fxml_control2,fxml_control3,fxml_control4,fxml_control5,fxml_control6,fxml_control7,fxml_control8,fxml_control9,fxml_control10,fxml_control11,fxml_control12;  	//Parent is a javafx class to control fxml file
	static FXMLLoader fxml_file,fxml_file2,fxml_file3,fxml_file4,fxml_file5,fxml_file6,fxml_file7,fxml_file8,fxml_file9,fxml_file10,fxml_file11,fxml_file12;  	//FXMLLoader is a javafx class to loads fxml file
	static Scene layer_in_stage,layer_in_stage2,layer_in_stage3,layer_in_stage4,layer_in_stage5,layer_in_stage6,layer_in_stage7,layer_in_stage8,layer_in_stage9,layer_in_stage10,layer_in_stage11,layer_in_stage12;// Scene is a javafx class to create layer in the stage	
	static String text ="ID ADMIN WAS NOT FOUND"; // variable class
	
	@Override
	public void start(Stage primaryStage) throws Exception {
			window = primaryStage; // define primaryStage equals 'window object'
			
			// Create Login Page
				fxml_control = fxml_file.load(getClass().getResource("Login_Ui.fxml")); // load fxml file and the file be controlled by Parent object
				layer_in_stage = new Scene(fxml_control); // create scene and its control is 'layar_in_stage'
				layer_in_stage.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // set css for the Scene
			//
				
			// Create Forgot Page
				fxml_control3 = fxml_file3.load(getClass().getResource("Forgot_Ui.fxml")); // load fxml file and the file be controlled by Parent object
				layer_in_stage3 = new Scene(fxml_control3); // create scene and its control is 'layar_in_stage'
				layer_in_stage3.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // set css for the Scene
			//
			
			// Create Reset Page
				fxml_control4 = fxml_file4.load(getClass().getResource("Reset_Ui.fxml")); // load fxml file and the file be controlled by Parent object
				layer_in_stage4 = new Scene(fxml_control4); // create scene and its control is 'layar_in_stage'
				layer_in_stage4.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // set css for the Scene
			//
				
			// Create Direktur Page
				fxml_file2 = new FXMLLoader(getClass().getResource("Direktur_Menu.fxml"));
				fxml_control2 = fxml_file2.load(); // load fxml file and the file be controlled by Parent object
				layer_in_stage2 = new Scene(fxml_control2); // create scene and its control is 'layar_in_stage'
				layer_in_stage2.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // set css for the Scene
			//
				
			// Create Suplier Page
				fxml_file5 = new FXMLLoader(getClass().getResource("Suplier_Ui.fxml"));
				fxml_control5 = fxml_file5.load(); // load fxml file and the file be controlled by Parent object
				layer_in_stage5 = new Scene(fxml_control5); // create scene and its control is 'layar_in_stage'
				layer_in_stage5.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // set css for the Scene
			//
				
			// Create Karyawan Page
				fxml_file6 = new FXMLLoader(getClass().getResource("Karyawan_Ui.fxml"));
				fxml_control6 = fxml_file6.load(); // load fxml file and the file be controlled by Parent object
				layer_in_stage6 = new Scene(fxml_control6); // create scene and its control is 'layar_in_stage'
				layer_in_stage6.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // set css for the Scene
			//
				
			// Create Admin Page
				fxml_file7 = new FXMLLoader(getClass().getResource("Admin_Ui.fxml"));
				fxml_control7 = fxml_file7.load(); // load fxml file and the file be controlled by Parent object
				layer_in_stage7 = new Scene(fxml_control7); // create scene and its control is 'layar_in_stage'
				layer_in_stage7.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // set css for the Scene
			//
				
			// Create Gaji Page
				fxml_file8 = new FXMLLoader(getClass().getResource("Gaji_Ui.fxml"));
				fxml_control8 = fxml_file8.load(); // load fxml file and the file be controlled by Parent object
				layer_in_stage8 = new Scene(fxml_control8); // create scene and its control is 'layar_in_stage'
				layer_in_stage8.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // set css for the Scene
			//
				
			// Create Pembelian Page
				fxml_file9 = new FXMLLoader(getClass().getResource("Pembelian_Ui.fxml"));
				fxml_control9 = fxml_file9.load(); // load fxml file and the file be controlled by Parent object
				layer_in_stage9 = new Scene(fxml_control9); // create scene and its control is 'layar_in_stage'
				layer_in_stage9.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // set css for the Scene
			//
			
			// Create Barang Page
				fxml_file10 = new FXMLLoader(getClass().getResource("Barang_Ui.fxml"));
				fxml_control10 = fxml_file10.load(); // load fxml file and the file be controlled by Parent object
				layer_in_stage10 = new Scene(fxml_control10); // create scene and its control is 'layar_in_stage'
				layer_in_stage10.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // set css for the Scene
			//
				
			// Create Pendapatan Page
				fxml_file12 = new FXMLLoader(getClass().getResource("Pendapatan_Ui.fxml"));
				fxml_control12 = fxml_file12.load(); // load fxml file and the file be controlled by Parent object
				layer_in_stage12 = new Scene(fxml_control12); // create scene and its control is 'layar_in_stage'
				layer_in_stage12.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // set css for the Scene
			//
						
			Image icon = new Image("/images/PROG_ICON.png"); // Set Software Icon
			window.setTitle("Light Studio");	// set title for the Stage
			window.setScene(layer_in_stage);	// put scene in stage
			window.getIcons().add(icon);		// set icon for the stage
			window.setResizable(false); 		// set the Stage can't Resizable
			window.show();						// show stage
	}
	
	// Dual Window Method
	void login() {
		//Stage
		window2 = new Stage(); 	// create stage and its object is window
		window2.initModality(Modality.APPLICATION_MODAL);	// create double Stage
		window2.setTitle("Message"); 	// Set stage title
		window2.setX(500);
		window2.setY(200);
		window2.setMinWidth(400); 		// min width of the stage
		window2.setMinHeight(300); 		// min height of the stage
		window2.setResizable(false); 	// set stage can't resizable
		
		//Atributs Of The Scene
		Label message = new Label(); 	// create label and its object is message
		message.setText(text); 			// set text for the label			
		Button btn = new Button("OK");  // create button and its object is btn
		btn.setPadding(new Insets(5,20,5,20)); // set padding button
		btn.setOnAction(event -> {
			window2.close();	// close stage
		});
		
		//Scene
		VBox layout = new VBox(10);// create container for stage and its object is layout
		layout.getChildren().addAll(message,btn);// add atribut to the container
		layout.setAlignment(Pos.CENTER); // set alignmebt
		Scene scene3 = new Scene(layout); // set layout as scene
		
		// run stage
		window2.setScene(scene3);
		window2.show();
	}
	
	void Riwayat_Penjualan_stage() {
		try {
			// SET STAGE
			window3 = new Stage(); // Object for the stage
			window3.initModality(Modality.APPLICATION_MODAL);	// create double Stage
			
			// SET SCENE
			// Create Pembelian Page
			fxml_file11 = new FXMLLoader(getClass().getResource("Riwayat_Penjualan.fxml"));
			fxml_control11 = fxml_file11.load(); // load fxml file and the file be controlled by Parent object
			layer_in_stage11 = new Scene(fxml_control11); // create scene and its control is 'layar_in_stage'
			layer_in_stage11.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // set css for the Scene
			
			Riwayat_Penjualan_Controller Riwayat_Penjualan_Controller_Object = fxml_file11.getController();	
			Riwayat_Penjualan_Controller_Object.show_data();// Run Method From Other Controllers
			
			Image icon = new Image("/images/PROG_ICON.png"); // Set Software Icon
			window3.setTitle("Light Studio");	// set title for the Stage
			window3.setScene(layer_in_stage11);	// put scene in stage
			window3.getIcons().add(icon);		// set icon for the stage
			window3.setResizable(false); 		// set the Stage can't Resizable
			window3.show();	
		} catch (Exception e) {
			// TODO: handle exception
		}	
	}
	
	public static void main(String[] args) {  // default method for main class, to run the program
		launch(args);
	}
}
