package application;

public class Pembelian {
    // class variable
		private String ID_PEMBELIAN,NAMA_BARANG,JENIS_BARANG,TGL_PEMBELIAN,KETERANGAN,HARGA_TOTAL,JUMLAH_BARANG;
	//
	
	public Pembelian (String id_pembelian, String nama_barang, String jenis_barang, String jumlah_barang, String harga_total, String tgl_pembelian, String Keterangan) {
		this.ID_PEMBELIAN = id_pembelian;
		this.NAMA_BARANG = nama_barang;
		this.JENIS_BARANG = jenis_barang;
		this.JUMLAH_BARANG = jumlah_barang;
		this.HARGA_TOTAL = harga_total;
		this.TGL_PEMBELIAN = tgl_pembelian;
		this.KETERANGAN = Keterangan;
	}
	public String getId_Pembelian() {
		return ID_PEMBELIAN;
	}
	public String getNama_Barang() {
		return NAMA_BARANG;
	}
	public String getJenis_Barang() {
		return JENIS_BARANG;
	}
	public String getJumlah_Barang() {
		return JUMLAH_BARANG;
	}
	public String getHarga_Total() {
		return HARGA_TOTAL;
	}
	public String getTgl_Pembelian() {
		return TGL_PEMBELIAN;
	}
	public String getKeterangan() {
		return KETERANGAN;
	}
}
