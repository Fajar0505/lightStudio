package application;

public class Record_data {
	//	CLASS VARIABLE
		private int amount;
		private String stuff;
		private String price; 
	//
	
	public Record_data(int amount, String stuff, String price) {
		this.amount = amount;
		this.stuff = stuff;
		this.price = price;
	}

	public int getAmount() {
		return amount;
	}

	public String getStuff() {
		return stuff;
	}

	public String getPrice() {
		return price;
	}


}
