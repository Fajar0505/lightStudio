package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;

// Import Static Attribut From My Own Class
import static application.Koneksi.*;
import static application.Main.*;

public class Login_Controller {
	Main Main_class = new Main(); 			// Create Object for Main Class
	static String id,login_username,index; 	// class Variables
	
	// Object for Fxml Componnets
	@FXML
	private Button btnlogin,btnforgot;
	@FXML
	private PasswordField passfield,idfield;
	//
	
	public void Button_Action(ActionEvent event) { // method for button of LOGIN_UI.FXML
		if(event.getSource() == btnlogin){
			login_process(); // run method login_procces
		}
		else if (event.getSource() == btnforgot) {
			// Set Value of Fxml  Component based its id
			//  codes = id + Method
			idfield.setText("");	 
			passfield.setText("");
			window.setScene(layer_in_stage3); // Move To Forgot Page
		}
	}
	
	//Login method
	void login_process() {		
		// variable method
		String id = idfield.getText();
		String pass = passfield.getText();
		//
		
		try {
			// set sql codes
			Class.forName(DRIVER);
			c = dm.getConnection(DB_URL,USER,PASS);		
			s = c.createStatement();
			r = s.executeQuery("SELECT * FROM admin WHERE id_admin='"+id+"' AND password='"+pass+"'");
			
			// login options
			if(r.next()) {
				if (id.equals(r.getString("id_admin")) && pass.equals(r.getString("password"))) {
					if (r.getString("status").equals("DIREKTUR")) { // Check Status for users After login
						
						// Set Value of Fxml  Component based its id
						//  codes = id + Method
						idfield.setText("");	 
						passfield.setText("");
												
						// set static variable to get data from the database
						//	codes = static variable + mysql object and method
						login_username = r.getString("username"); 
						index = r.getString("status");
						
						// Object Controller Class
						Direktur_Controller Direktur_Controller_Object = fxml_file2.getController();
						Barang_Controller Barang_Controller_Object = fxml_file10.getController();
						Pembelian_Controller Pembelian_Controller_Object = fxml_file9.getController();
						
						// Run Method From Other Controllers
						Direktur_Controller_Object.show_name();
						Direktur_Controller_Object.show_data();
						Direktur_Controller_Object.BUTTONS_VISIBLE();
						Barang_Controller_Object.BUTTONS_VISIBLE();
						Pembelian_Controller_Object.BUTTONS_VISIBLE();
						
						// Set The Stage
						//  codes = Stage Objects + Stage Methods
						window.setX(45);  // set the stage possition based X
						window.setY(5);	  // set the stage possition based Y
						window.setResizable(true); 			// set the stage can be resize				
						window.setScene(layer_in_stage2); 	// move to Direktur_Ui
						
						
					}else if (r.getString("status").equals("KARYAWAN")) {
						// Set Value of Fxml  Component based its id
						//  codes = id + Method
						idfield.setText("");	 
						passfield.setText("");
						
						// set static variable to get data from the database
						//	codes = static variable + mysql object and method
						login_username = r.getString("username"); 
						index = r.getString("status"); 
						
						// 
						Direktur_Controller Direktur_Controller_Object = fxml_file2.getController();
						Barang_Controller Barang_Controller_Object = fxml_file10.getController();
						Pembelian_Controller Pembelian_Controller_Object = fxml_file9.getController();
						
						// Run Method From Other Controllers
						Direktur_Controller_Object.show_name();
						Direktur_Controller_Object.show_data();
						Direktur_Controller_Object.BUTTONS_VISIBLE();
						Barang_Controller_Object.BUTTONS_VISIBLE();
						Pembelian_Controller_Object.BUTTONS_VISIBLE();
						// Set The Stage
						//  codes = Stage Objects + Stage Methods
						window.setX(45);  // set the stage possition based X
						window.setY(5);	  // set the stage possition based Y
						window.setResizable(true); 			// set the stage can be resize				
						window.setScene(layer_in_stage2); 	// move to Direktur_Ui
						
					}
				}
			}
			else { // show popup 
				text= "ID OR PASSWORD WAS WRONG";	// Set Value For Main Class Variable	
				Main_class.login();	// run method login by the object
				
				// Set Value of Fxml  Component based its id
				//  codes = id + Method
				idfield.setText("");	 
				passfield.setText("");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
